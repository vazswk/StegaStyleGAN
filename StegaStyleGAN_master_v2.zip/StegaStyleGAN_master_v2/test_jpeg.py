import argparse
import math
import random
import os
import pickle

import numpy as np
import torch
from torch import nn, autograd, optim
from torch.nn import functional as F
from torch.utils import data
import torch.distributed as dist
from torchvision import transforms, utils
from tqdm import tqdm
from torch.nn.functional import binary_cross_entropy_with_logits

# from op import conv2d_gradfix

import numpy as np
import torch

# from old_ste_model import Decoder, MsgModulator
from PIL import Image

from utils import *

os.environ['CUDA_VISIBLE_DEVICES'] = '1'



transform = transforms.Compose(
        [
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5), inplace=True),
        ]
    )


def tensor_to_image(tensor):
    """
    Transforms a torch tensor into numpy uint8 array (image)
    :param tensor: (batch_size x channels x height x width) torch tensor in range [-1.0, 1.0]
    :return: (batch_size x height x width x channels) uint8 array
    """
    image = tensor.permute(0, 2, 3, 1).detach().cpu().numpy()
    image = (image + 1.) * 127.5
    return np.clip(image, 0, 255).astype(np.uint8)

def tensor01_to_image(tensor):
    """
    Transforms a torch tensor into numpy uint8 array (image)
    :param tensor: (batch_size x channels x height x width) torch tensor in range [-1.0, 1.0]
    :return: (batch_size x height x width x channels) uint8 array
    """
    image = tensor.permute(0, 2, 3, 1).detach().cpu().numpy()
    image = (image) * 255.0
    return np.clip(image, 0, 255).astype(np.uint8)


def sample2path(g_ema, n_sample, path, batch_size, device, latent_size, type='jpg'):
    #将载密位图生成到目标目录，保存为相应格式
    cnt = 0
    for idx in tqdm(range(n_sample//batch_size)):

        sample_z = torch.randn(batch_size, latent_size, device=device)
        g_ema.eval()
        sample, _ = g_ema([sample_z])
        


def unnormalize(x):
    # x = torch.clamp(x,-1,1)
    x = torch.round(255.0 * (x + 1.0) / 2.0)
    return x

def normalize(x):
    x = x / 127.5 - 1.0
    return x



if __name__ == "__main__":
    device = "cuda"

    parser = argparse.ArgumentParser(description="sample to path")

    

    args = parser.parse_args()

    
    # if not os.path.exists(os.path.join(args.out,"residual")):
    #     os.mkdir(os.path.join(args.out,"residual"))
    


    


    from noise_layers.noiser import Noiser, Identity, JpegCompression,ASLJPEG,REALJPEG,SUJPEG,  GF, GN, MF, SP, AF, Rotate, Speckle,Resize
    # import kornia

    de = 'cuda'

    # buffer = BytesIO(img_bytes)
    img = Image.open('9.jpg')
    # img = img.resize((128, 128))
    # img.save('2jpg.jpg',quality=75)


    # re_img = Image.open('2jpg.jpg')
    # re_img = transform(re_img)
    # re_img = re_img.cuda()
    # re_img = re_img[None,:]


    img = transform(img)
    img = img.cuda()
    img = img[None,:]
    print(img.shape)

    # stego_path = os.path.join(args.out,"stego", str(cnt)+'.'+type_name)
            # stego.save(stego_path,quality=65)
            # stego.save(stego_path,quality=65)

            # re_img = Image.open(stego_path)
    
            # re_img = transform(re_img)
            # re_img = re_img.cuda()
            # re_img = re_img[None,:]


    x_ori = unnormalize(img)

    print(torch.max(x_ori))
    print(torch.min(x_ori))



    
    p = np.array([1])   # 各个信道攻击的采样概率
    # pipeline = Noiser(noise_layers=[Identity(), 'JpegPlaceholder'], device='cuda', prob=p) #信道噪声模拟模块
    pipeline = Noiser(noise_layers=[Resize((2.7,2.7))], device=de, prob=p) #信道噪声模拟模块


    gf_img = pipeline(img)
    # pipeline_real = Noiser(noise_layers=['REALJpeg'], device=de, prob=p) #信道噪声模拟模块
    # pipeline_asl = Noiser(noise_layers=['ASLJpeg'], device=de, prob=p) #信道噪声模拟模块
    # valid_pipeline = Noiser(noise_layers=['JpegPlaceholder'], device=de) #验证时的信道噪声模拟模块
    # jpeg75 = JpegCompression(de, quality=75)
#
    # jpeg95 = JpegCompression(de, quality=95)

    # sujpeg = SUJPEG(quality=75)

    


    # jp1 = unnormalize( pipeline(img) )
    # jp2 = unnormalize( pipeline_real(img))
    # jp3 = unnormalize(jpeg75(img))
    # print("wan  forward ~~~~~~~~~~~~~~~~~~")
    # jp4 = unnormalize(jpeg75(img,quan=True))
    # jp5 = unnormalize(jpeg95(img,quan=True))
    # jp5 = unnormalize(sujpeg(img))
    # print("asl real ~~~~~~~~")
    # jp5 = unnormalize(pipeline_asl(img))
    # jp6 = unnormalize(pipeline_real(img))

    # jp5 = pipeline_asl(img)
    # jp6 = pipeline_real(img)
    # jpsu = unnormalize(sujpeg(img))



    # print(jpsu)

    # print(jp5)
    # print(jp6)
    
    # print(jp4)
    # print(jp6)
    # print(jp5==jp6)
    # print(torch.sum(torch.abs(jpsu-jp4)))
    # print(x_ori.numel())






    
    sec_sample = tensor_to_image(gf_img)
        
    stego = Image.fromarray(sec_sample[0, :, :, :])
    stego.save(os.path.join("haha/stegohahaha.png"))

        # noise_sample, _ = g([latent_z], noise=ori_noise)
        # finallayer_noise = torch.randn(args.batch, args.bpp, args.size, args.size).to(device)




        # print(torch.max(fake_img))
        # print(torch.min(fake_img))
        # fake_img = fake_img / 127.5 - 1.0
        #decoder gradient
        # fake_image =  127.5 * (fake_image + 1.0)
        # noised_image = pipeline(fake_image)
        
        # noised_image = noised_image / 127.5 - 1.0
        # msg_pred = decoder(fake_img) 
        # label = msg_gt>=0.5
        # print(msg_pred)
        # dec_acc = (msg_pred >= 0.0).eq(label).sum().float() / msg_gt.numel()
        # print(dec_acc)
        # acc += dec_acc
        # if i % 100==0:
            # print("accumu")
            # print(acc/(i+1))

            
        