import torch
from model import EqualConv2d, EqualLinear
from torch import nn
from torch.nn import init
from torch.nn import functional as F
from torch.autograd import Function

from math import sqrt

import random




class MsgModulator(nn.Module):
    def __init__(self, hidden_size=64, data_depth=1, kernel_size=3, emb_step=5):
        super().__init__()
        self.hidden_size = hidden_size
        self.data_depth = data_depth
        self.kernel_size = kernel_size
        self.emb_step = emb_step

        self.conv1 = nn.Sequential(
            EqualConv2d(self.data_depth, self.hidden_size, self.kernel_size, padding=self.kernel_size//2),
            # nn.BatchNorm2d(self.hidden_size),
            nn.LeakyReLU(inplace=True),
        )

        self.conv2 = nn.Sequential(
            EqualConv2d(self.hidden_size, self.hidden_size, self.kernel_size, stride=1, padding=self.kernel_size//2),
            nn.LeakyReLU(inplace=True),
            EqualConv2d(self.hidden_size, self.hidden_size, self.kernel_size, stride=1, padding=self.kernel_size//2),
            nn.LeakyReLU(inplace=True),
        )

        self.conv3 = nn.Sequential(
            EqualConv2d(self.hidden_size, self.hidden_size, self.kernel_size, stride=1, padding=self.kernel_size//2),
            nn.LeakyReLU(inplace=True),
            EqualConv2d(self.hidden_size, self.hidden_size, self.kernel_size, stride=1, padding=self.kernel_size//2),
            nn.LeakyReLU(inplace=True),
        )
        self.conv4 = nn.Sequential(
            EqualConv2d(self.hidden_size, self.data_depth, self.kernel_size, padding=self.kernel_size//2),
            nn.Tanh()
        )

        # self.conv5 = nn.Sequential(
        #     EqualConv2d(self.hidden_size, self.hidden_size, self.kernel_size, stride=2, padding=self.kernel_size//2),
        #     nn.LeakyReLU(inplace=True),
        # )
        # self.conv6 = nn.Sequential(
        #     EqualConv2d(self.hidden_size, self.hidden_size, self.kernel_size, stride=1, padding=self.kernel_size//2),
        #     nn.LeakyReLU(inplace=True),
        # )
        # self.conv7 = nn.Sequential(
        #     nn.Conv2d(self.hidden_size, 2, self.kernel_size, padding=self.kernel_size//2),
        # )


    def forward(self, x):
        x1 = self.conv1(x)
        x2 = x1 + self.conv2(x1)
        x3 = x2 + self.conv3(x2)
        x = self.conv4(x3)

        # x = self.conv3(self.conv2(self.conv1(x)))
        # x1 = self.conv4(x)
        # x2 = self.conv7(self.conv6(self.conv5(x)))

        return x
    

class Decoder(nn.Module):
    def __init__(self, hidden_size=64, data_depth=1, kernel_size=5, emb_step=7, log_size = 7, msg_repeat = 1, wanway=False):
        super().__init__()
        self.hidden_size = hidden_size
        self.data_depth = data_depth
        self.kernel_size = kernel_size
        self.emb_step = emb_step
        self.log_size = log_size
        self.msg_repeat = msg_repeat
        self.wanway = wanway

        self._models = self._build_models()

    def _build_models(self):
        self.conv1 = nn.Sequential(
            EqualConv2d(3, self.hidden_size, self.kernel_size, padding=self.kernel_size//2),
            nn.LeakyReLU(inplace=True),
        )

        self.conv2 = nn.Sequential(
            EqualConv2d(self.hidden_size, self.hidden_size, self.kernel_size, padding=self.kernel_size//2),
            nn.LeakyReLU(inplace=True),
        )

        self.conv3 = nn.Sequential(
            EqualConv2d(self.hidden_size * 2, self.hidden_size, self.kernel_size, padding=self.kernel_size//2),
            nn.LeakyReLU(inplace=True),
        )
        self.conv4 = nn.Sequential(
            EqualConv2d(self.hidden_size * 3, self.hidden_size, self.kernel_size, padding=self.kernel_size//2),
            nn.LeakyReLU(inplace=True),
        )
        # self.conv4 = nn.Sequential(
        #     EqualConv2d(self.hidden_size * 3, self.hidden_size),
        #     nn.LeakyReLU(inplace=True),
        # )
        self.conv5 = nn.Sequential(EqualConv2d(self.hidden_size * 4, self.data_depth,
                                               self.kernel_size, padding=self.kernel_size//2))

        return self.conv1, self.conv2, self.conv3, self.conv4, self.conv5

    def forward(self, x):
        # if x.shape[2]!=128 or x.shape[3]!=128:
        #     x = F.interpolate(x, size=(128, 128), mode='nearest')
        x = self._models[0](x)

        if len(self._models) > 1:
            x_list = [x]
            for layer in self._models[1:]:
                x = layer(torch.cat(x_list, dim=1))
                x_list.append(x)
            
            if self.emb_step < self.log_size:
                # print("x shape before after")
                # print(x.shape)
                if self.wanway:
                    x = F.avg_pool2d(x, kernel_size=2**(self.log_size-self.emb_step), stride=2**(self.log_size-self.emb_step))
                # print(x.shape)
                else:
                    x = split_avg1(x, 2**(self.log_size-self.emb_step), (2**(self.log_size-self.emb_step))/self.msg_repeat)
                    
        
        return x



def split_avg(x, h_chunk, w_chunk):
    c0 = torch.chunk(x,h_chunk,2)
    # print(c0)
    out = None
    for i in c0:
        c1 = torch.chunk(i, w_chunk, 3)
        for j in c1:
            print(j)
            if out is None:
                out = j.clone()
            else:
                tt = j.clone()
                out = torch.cat((out,tt),dim=1)
            print(out)
            # out_list.append(j)
    # print(out_list[0])
    # print(out_list[1])
    # print(out_list)
    # out_tuple = tuple(out_list)
    # print(out_tuple)
    # out = torch.cat(out_list, dim = 1)

    # return (out_list[0]+out_list[1]+out_list[2]+out_list[3])/4.0

    # print(out)
    # print(out.shape)
    return torch.mean(out,dim=1, keepdim=True)


def split_avg1(x, h_chunk, w_chunk):
    h_chunk = int(h_chunk)
    w_chunk = int(w_chunk)
    c0 = torch.chunk(x,h_chunk,2)
    # print(c0)
    out_list = []
    for i in c0:
        c1 = torch.chunk(i, w_chunk, 3)
        for j in c1:
            out_list.append(j.clone())
    # print(out_list[0])
    # print(out_list[1])
    # print(out_list)
    # out_tuple = tuple(out_list)
    # print(out_tuple)
    out = torch.cat(out_list, dim = 1)

    # return (out_list[0]+out_list[1]+out_list[2]+out_list[3])/4.0

    # print(out)
    # print(out.shape)
    return torch.mean(out,dim=1, keepdim=True)
