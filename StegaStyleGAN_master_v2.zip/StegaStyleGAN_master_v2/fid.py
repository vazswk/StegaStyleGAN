import argparse
import pickle

import os

os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'
os.environ['CUDA_VISIBLE_DEVICES'] = '3'

import torch
from torch import nn
import numpy as np
from scipy import linalg
from tqdm import tqdm
import pathlib


from calc_inception import load_patched_inception_v3
from old_ste_model import Decoder, MsgModulator
from utils import old_generate_modulated_noise, attack_generate_modulated_noise_args, old_generate_01, bonuli_test
    


def generate_modulated_01(batch_size, img_size, device, msg_model = None, ori_noise = None): # 用秘密信息调制噪声图
    # noise = []
    msg = torch.zeros(batch_size, 1, img_size, img_size).random_(0, 2).to(device)
    # payload_step = msg * 2 - 1
    # if ori_noise is None:
    #     ori_noise = torch.randn(batch_size, 1, img_size, img_size).to(device)
    # ori_noise = torch.abs(ori_noise)
    # modeuated_noise = ori_noise.mul(payload_step)
    # if msg_model != None:
    #     # print(" mod noise ...")
    #     modeuated_noise = msg_model(modeuated_noise)
    return msg, msg


@torch.no_grad()
def extract_feature_from_stego_samples(
    generator, mod, inception, truncation, truncation_latent, batch_size, n_sample, bpp, device
):
    n_batch = n_sample // batch_size
    resid = n_sample - (n_batch * batch_size)
    if resid==0:
        batch_sizes = [batch_size] * n_batch
    else:
        batch_sizes = [batch_size] * n_batch + [resid]
    features = []

    for batch in tqdm(batch_sizes):
        latent = torch.randn(batch, 512, device=device)
        # modeuated_noise, msg_gt = old_generate_modulated_noise(batch, args.size, device, msg_model=mod, bpp=bpp)
        modeuated_noise, msg_gt = bonuli_test(batch, args.size, device, msg_model=mod, bpp=bpp, prob=0.5)
        # print(modeuated_noise.shape)
        img, _ = generator([latent], emb_secret=True, modeuated_noise=modeuated_noise, truncation=truncation, truncation_latent=truncation_latent)
        # print("wtf???????")
        feat = inception(img)[0].view(img.shape[0], -1)
        features.append(feat.to("cpu"))

    features = torch.cat(features, 0)

    return features


@torch.no_grad()
def extract_feature_from_samples(
    generator, inception, truncation, truncation_latent, batch_size, n_sample, device
):
    n_batch = n_sample // batch_size
    resid = n_sample - (n_batch * batch_size)
    if resid==0:
        batch_sizes = [batch_size] * n_batch
    else:
        batch_sizes = [batch_size] * n_batch + [resid]
    features = []

    for batch in tqdm(batch_sizes):
        latent = torch.randn(batch, 512, device=device)
        img, _ = generator([latent], truncation=truncation, truncation_latent=truncation_latent)
        # print("wtf???????")
        feat = inception(img)[0].view(img.shape[0], -1)
        features.append(feat.to("cpu"))

    features = torch.cat(features, 0)

    return features


@torch.no_grad()
def calc_mu_sigma_from_samples(
    generator, batch_size, n_sample, device
):
    n_batch = n_sample // batch_size
    resid = n_sample - (n_batch * batch_size)
    batch_sizes = [batch_size] * n_batch + [resid]
    features = []

    inception = nn.DataParallel(load_patched_inception_v3()).to(device)
    inception.eval()

    for batch in tqdm(batch_sizes):
        latent = torch.randn(batch, 512, device=device)
        img, _ = generator([latent])
        feat = inception(img)[0].view(img.shape[0], -1)
        features.append(feat.to("cpu"))

    features = torch.cat(features, 0)
    features = features.numpy()
#     print(f"extracted {features.shape[0]} features")

    sample_mean = np.mean(features, 0)
    sample_cov = np.cov(features, rowvar=False)

    return sample_mean, sample_cov



@torch.no_grad()
def extract_feature_from_01_stego_samples(
    generator, inception, truncation, truncation_latent, batch_size, n_sample, device
):
    n_batch = n_sample // batch_size
    resid = n_sample - (n_batch * batch_size)
    if resid==0:
        batch_sizes = [batch_size] * n_batch
    else:
        batch_sizes = [batch_size] * n_batch + [resid]
    features = []

    for batch in tqdm(batch_sizes):
        latent = torch.randn(batch, 512, device=device)
        modeuated_noise, msg_gt = generate_modulated_01(batch, args.size, device)
        # print(modeuated_noise)
        img, _ = generator([latent], emb_secret=True, modeuated_noise=modeuated_noise, truncation=truncation, truncation_latent=truncation_latent)
        # print("wtf???????")
        feat = inception(img)[0].view(img.shape[0], -1)
        features.append(feat.to("cpu"))

    features = torch.cat(features, 0)

    return features



@torch.no_grad()
def extract_feature_from_attackstego_samples(
    generator, mod, inception, truncation, truncation_latent, batch_size, n_sample, emb_step, lasttwo, msg_repeat, device
):
    n_batch = n_sample // batch_size
    resid = n_sample - (n_batch * batch_size)
    if resid==0:
        batch_sizes = [batch_size] * n_batch
    else:
        batch_sizes = [batch_size] * n_batch + [resid]
    features = []

    for batch in tqdm(batch_sizes):
        latent = torch.randn(batch, 512, device=device)
        modeuated_noise, msg_gt = attack_generate_modulated_noise(batch, args.size, device, msg_model=mod, msg_size=2**(emb_step), lasttwo=lasttwo, msg_repeat=msg_repeat)
        # attack_generate_modulated_noise(args.batch, args.size, device , msg_model=mod, msg_size=args.msg_size)
        # print(modeuated_noise)
        img, _ = generator([latent], emb_secret=True, modeuated_noise=modeuated_noise, truncation=truncation, truncation_latent=truncation_latent)
        # print("wtf???????")
        feat = inception(img)[0].view(img.shape[0], -1)
        features.append(feat.to("cpu"))

    features = torch.cat(features, 0)

    return features


@torch.no_grad()
def calc_mu_sigma_from_stego_samples(
    generator, batch_size, n_sample, mod, device, args
):
    n_batch = n_sample // batch_size
    resid = n_sample - (n_batch * batch_size)
    if resid!=0:
        batch_sizes = [batch_size] * n_batch + [resid]
    else:
        batch_sizes = [batch_size] * n_batch
    features = []

    inception = load_patched_inception_v3().to(device)
    inception.eval()

    for batch in tqdm(batch_sizes):
        latent = torch.randn(batch, 512, device=device)
        info_noise, _ = old_generate_modulated_noise(batch, 
                args.size, device , msg_model=mod, bpp=args.bpp)
        img, _ = generator([latent], randomize_noise=True, emb_secret=True, modeuated_noise=info_noise)
        
        
        feat = inception(img)[0].view(img.shape[0], -1)
        features.append(feat.to("cpu"))

    features = torch.cat(features, 0)
    features = features.numpy()
#     print(f"extracted {features.shape[0]} features")

    sample_mean = np.mean(features, 0)
    sample_cov = np.cov(features, rowvar=False)

    return sample_mean, sample_cov



@torch.no_grad()
def calc_mu_sigma_from_01stego_samples(
    generator, batch_size, n_sample, mod, device, args
):
    n_batch = n_sample // batch_size
    resid = n_sample - (n_batch * batch_size)
    if resid!=0:
        batch_sizes = [batch_size] * n_batch + [resid]
    else:
        batch_sizes = [batch_size] * n_batch
    features = []

    inception = load_patched_inception_v3().to(device)
    inception.eval()

    for batch in tqdm(batch_sizes):
        latent = torch.randn(batch, 512, device=device)

        
        info_noise, _ = old_generate_01(batch, args.size, device , msg_model=mod, bpp=args.bpp)
        img, _ = generator([latent], randomize_noise=True, emb_secret=True, modeuated_noise=info_noise)
        
        # img, _ = generator([latent], emb_secret=True, modeuated_noise=modeuated_noise)
        # img, _ = generator([latent])
        feat = inception(img)[0].view(img.shape[0], -1)
        features.append(feat.to("cpu"))

    features = torch.cat(features, 0)
    features = features.numpy()
#     print(f"extracted {features.shape[0]} features")

    sample_mean = np.mean(features, 0)
    sample_cov = np.cov(features, rowvar=False)

    return sample_mean, sample_cov







@torch.no_grad()
def calc_mu_sigma_from_attack_samples(
    generator, args, batch_size, n_sample, mod, device
):
    # img_size, emb_step, lasttwo, msg_repeat, wanway
    n_batch = n_sample // batch_size
    resid = n_sample - (n_batch * batch_size)
    if resid!=0:
        batch_sizes = [batch_size] * n_batch + [resid]
    else:
        batch_sizes = [batch_size] * n_batch
    features = []

    inception = load_patched_inception_v3().to(device)
    inception.eval()

    for batch in tqdm(batch_sizes):
        latent = torch.randn(batch, 512, device=device)
        
        
        modeuated_noise, msg_gt = attack_generate_modulated_noise_args(batch, device, args, msg_model=mod, ori_noise=None)
        
        # attack_generate_modulated_noise(args.batch, args.size, device , msg_model=mod, msg_size=args.msg_size)
        # print(modeuated_noise)
        img, _ = generator([latent], emb_secret=True, modeuated_noise=modeuated_noise)
        # print("wtf???????")
        feat = inception(img)[0].view(img.shape[0], -1)
        features.append(feat.to("cpu"))

    features = torch.cat(features, 0)
    features = features.numpy()
#     print(f"extracted {features.shape[0]} features")

    sample_mean = np.mean(features, 0)
    sample_cov = np.cov(features, rowvar=False)

    return sample_mean, sample_cov



def calc_fid(sample_mean, sample_cov, real_mean, real_cov, eps=1e-6):
    cov_sqrt, _ = linalg.sqrtm(sample_cov @ real_cov, disp=False)

    if not np.isfinite(cov_sqrt).all():
        print("product of cov matrices is singular")
        offset = np.eye(sample_cov.shape[0]) * eps
        cov_sqrt = linalg.sqrtm((sample_cov + offset) @ (real_cov + offset))

    if np.iscomplexobj(cov_sqrt):
        if not np.allclose(np.diagonal(cov_sqrt).imag, 0, atol=1e-3):
            m = np.max(np.abs(cov_sqrt.imag))

            raise ValueError(f"Imaginary component {m}")

        cov_sqrt = cov_sqrt.real

    mean_diff = sample_mean - real_mean
    mean_norm = mean_diff @ mean_diff

    trace = np.trace(sample_cov) + np.trace(real_cov) - 2 * np.trace(cov_sqrt)

    fid = mean_norm + trace

    return fid




if __name__ == "__main__":
    device = "cuda"

    parser = argparse.ArgumentParser(description="Calculate FID scores")

    parser.add_argument("--truncation", type=float, default=1, help="truncation factor")
    parser.add_argument(
        "--truncation_mean",
        type=int,
        default=4096,
        help="number of samples to calculate mean for truncation",
    )
    parser.add_argument(
        "--batch", type=int, default=64, help="batch size for the generator"
    )
    parser.add_argument(
        "--n_sample",
        type=int,
        default=50000,
        help="number of the samples for calculating FID",
    )
    parser.add_argument(
        "--size", type=int, default=128, help="image sizes for generator"
    )
    parser.add_argument(
        "--inception",
        type=str,
        default="inception_celeba_128.pkl",   # calc_inception 生成
        help="path to precomputed inception embedding",
    )
    parser.add_argument(
        "--bpp",
        type=int,
        default=1,
        help="lastone embed noise",
    )
    parser.add_argument(
        "--noise_type",      # 可以是ori 么？
        type=str,
        default="lastone",
        help="",
    )
    parser.add_argument(
        "--ckpt",
        type=str,
        default=r"checkpoint_celeba_new_jtcompare_bpp4_dec0.75_batch16_seed75_decayto0.75_128/425000.pt",
        help="",
    )
    parser.add_argument(
        "--emb_step",
        type=int,
        default=7,
        help="",
    )
    parser.add_argument(
        "--withmod",
        action = "store_true",   # 弃用
        
    )
    parser.add_argument(
        "--lasttwo",
        action = "store_true",  # 弃用
    )
    parser.add_argument(
        "--msg_repeat",
        type=int,
        default=1,    # 默认
        help="",
    )

    args = parser.parse_args()

    ckpt = torch.load(args.ckpt)

    # if args.bpp==1:
    #     if args.lasttwo:
    #         print("model load from lasttwo")
    #         from model_lasttwo import Generator
    #     else:
    #         print("model load from lastone")
    #         from model_lastone import Generator
    # elif args.bpp==0:
    #     from model import Generator
    # elif args.bpp==2:
    #     from model_lastone_bpp2 import Generator

    
    if args.bpp==0:
        from model import Generator  # 此处代码不成熟，请使用原始StyelGAN中的代码来实现
    else:
        from model_lastone_bppn import Generator

    if args.bpp > 0:
        g = Generator(args.size, 512, 8, bpp=args.bpp).to(device)
    g.load_state_dict(ckpt["g_ema"])
    # g = nn.DataParallel(g)
    g.eval()

    # d = Decoder(emb_step=5).to(device)
    # if "decoder_ema" in ckpt:
    #     d.load_state_dict(ckpt["decoder_ema"])
    # d.eval()

    if args.withmod:
        if args.lasttwo:
            mod = MsgModulator(data_depth=2).to(device)
        else:
            mod = MsgModulator(data_depth=args.bpp).to(device)
        mod.load_state_dict(ckpt["mod_ema"])
        mod.eval()
    else:
        mod = None

    if args.truncation < 1:
        with torch.no_grad():
            mean_latent = g.mean_latent(args.truncation_mean)  # 这个是啥意思

    else:
        mean_latent = None

    inception = load_patched_inception_v3().to(device)
    inception.eval()

    if args.noise_type == "ori":
        features = extract_feature_from_samples(
            g, inception, args.truncation, mean_latent, args.batch, args.n_sample, device
        ).numpy()
        print(f"extracted {features.shape[0]} features")
    elif args.noise_type == "lastone":
        features = extract_feature_from_stego_samples(
            g, mod, inception, args.truncation, mean_latent, args.batch, args.n_sample, args.bpp, device
        ).numpy()
        print(f"extracted {features.shape[0]} features")
    elif args.noise_type == "lastone01":
        features = extract_feature_from_01_stego_samples(
            g, inception, args.truncation, mean_latent, args.batch, args.n_sample, device
        ).numpy()
        print(f"extracted {features.shape[0]} features")
    elif args.noise_type == "attack":
        print("attack noise")
        raise("abandon attack !!!")
        features = extract_feature_from_attackstego_samples(
            g, mod, inception, args.truncation, mean_latent, args.batch, args.n_sample, args.emb_step, args.lasttwo, args.msg_repeat, device
        ).numpy()
        print(f"extracted {features.shape[0]} features")


    for i in range(20000,args.n_sample+1,10000):   # 分别计算 20000， 30000， 40000， 50000个样本条件下的FID么，间隔可以换成5000
        
        sub_features = features[:i]
        sample_mean = np.mean(sub_features, 0)
        sample_cov = np.cov(sub_features, rowvar=False)

        with open(args.inception, "rb") as f:
            embeds = pickle.load(f)
            real_mean = embeds["mean"]
            real_cov = embeds["cov"]

        fid = calc_fid(sample_mean, sample_cov, real_mean, real_cov)
        print(f"i: sample {i}")
        print("fid:", fid)