import argparse
import math
import random
import os
import pickle
os.environ['CUDA_VISIBLE_DEVICES'] = '0'
import numpy as np
import torch
from torch import nn, autograd, optim
from torch.nn import functional as F
from torch.utils import data
import torch.distributed as dist
from torchvision import transforms, utils
from tqdm import tqdm
from torch.nn.functional import binary_cross_entropy_with_logits

from op import conv2d_gradfix

import numpy as np
import torch

from old_ste_model import Decoder, MsgModulator
from PIL import Image

from utils import *

from noise_layers.noiser import Noiser, Identity, JpegCompression, ASLJPEG, REALJPEG



transform = transforms.Compose(
        [
            
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5), inplace=True),
        ]
    )


def tensor_to_image(tensor):
    """
    Transforms a torch tensor into numpy uint8 array (image)
    :param tensor: (batch_size x channels x height x width) torch tensor in range [-1.0, 1.0]
    :return: (batch_size x height x width x channels) uint8 array
    """
    image = tensor.permute(0, 2, 3, 1).detach().cpu().numpy()
    image = (image + 1.) * 127.5
    return np.clip(image, 0, 255).astype(np.uint8)


def sample2path(g_ema, n_sample, path, batch_size, device, latent_size, type='jpg'):
    #将载密位图生成到目标目录，保存为相应格式
    cnt = 0
    for idx in tqdm(range(n_sample//batch_size)):

        sample_z = torch.randn(batch_size, latent_size, device=device)
        g_ema.eval()
        sample, _ = g_ema([sample_z])
        


# def generate_modulated_noise(batch_size, img_size, device, msg_model = None, ori_noise = None): # 用秘密信息调制噪声图
#     # noise = []
#     msg = torch.zeros(batch_size, 1, img_size, img_size).random_(0, 2).to(device)
#     payload_step = msg * 2 - 1
#     if ori_noise is None:
#         ori_noise = torch.randn(batch_size, 1, img_size, img_size).to(device)
#     ori_noise = torch.abs(ori_noise)
#     modeuated_noise = ori_noise.mul(payload_step)
#     if msg_model != None:
#         print(" mod noise ...")
#         modeuated_noise = msg_model(modeuated_noise)
#     return modeuated_noise, msg


# def generate_modulated_noise(batch_size, img_size, device, msg_model = None, ori_noise = None, bpp=1): # 用秘密信息调制噪声图
#     # noise = []
#     msg = torch.zeros(batch_size, bpp, img_size, img_size).random_(0, 2).to(device)
#     payload_step = msg * 2 - 1
#     if ori_noise is None:
#         ori_noise = torch.randn(batch_size, 1, img_size, img_size).to(device)
#     if bpp==2:
#         if ori_noise.shape[1]==1:
#             ori_noise = ori_noise.repeat(1,bpp,1,1)
#         else:
#             print("noise channel error")
#     print(ori_noise.shape[1])
#     ori_noise = torch.abs(ori_noise)
#     modeuated_noise = ori_noise.mul(payload_step)
#     if msg_model != None:
#         # print(" mod noise ...")
#         modeuated_noise = msg_model(modeuated_noise)
#     return modeuated_noise, msg



if __name__ == "__main__":
    device = "cuda"

    parser = argparse.ArgumentParser(description="sample to path")

    parser.add_argument(
        "--ckpt",
        type=str,
        default=r"attack_bppn_model\checkpoint_celeba_jpeg75asl_msgrepeat1_emb5_dec0.7_bpp1_batch16_seed75_size128_jt_decayto0.7_wanway\370000.pt"
    )
    # checkpoint_celebhq_seed35_batch12_nojingtiao_oriseed35_continue_128\250000.pt

    parser.add_argument(
        "--out",
        type=str,
        default=r"E:\image\stylegan_output\robust\rebuttal\128\socialtest"
    )

    parser.add_argument(
        "--size", type=int, default=128, help="image sizes for generator"
    )

    parser.add_argument(
        "--n_sample", type=int, default=10000
    )

    parser.add_argument(
        "--batch", type=int, default=10
    )

    parser.add_argument(
        "--emb_step", type=int, default=7
    )

    parser.add_argument(
        "--bpp", type=int, default=1
    )
    parser.add_argument(
        "--withmod",
        # type=bool,
        # default=True,
        action = "store_true",
        help="msg ",
    )
    parser.add_argument(
        "--attack",
        # type=bool,
        # default=True,
        action = "store_true",
        help="msg ",
    )
    parser.add_argument(
        "--lasttwo",
        # type=bool,
        # default=True,
        action = "store_true",
        help="msg ",
    )
    parser.add_argument(
        "--msg_repeat", type=int, default=1
    )
    parser.add_argument(
        "--wanway",
        action = "store_true",   
    )

    

    

    args = parser.parse_args()
    args.log_size = int(math.log(args.size, 2))
    args.emb_idx = -(1+(args.log_size-args.emb_step)*2)

    valid_pipeline = Noiser(noise_layers=[ASLJPEG(height=args.size, width=args.size, quality=75)], device='cuda') #验证时的信道噪声模拟模块
    pipeline = Noiser(noise_layers=['ASLJpeg'], device='cuda') #验证时的信道噪声模拟模块


    if not os.path.exists(os.path.join(args.out)):
        os.makedirs(os.path.join(args.out))
    
    if not os.path.exists(os.path.join(args.out,"cover")):
        os.mkdir(os.path.join(args.out,"cover"))
    if not os.path.exists(os.path.join(args.out,"stego")):
        os.mkdir(os.path.join(args.out,"stego"))
    # if not os.path.exists(os.path.join(args.out,"residual")):
    #     os.mkdir(os.path.join(args.out,"residual"))
    


    if args.wanway:
        from model_attack_bppn import Generator, Discriminator



    ckpt = torch.load(args.ckpt)

    g = Generator(
        args.size, 512, 8, emb_step=args.emb_step, bpp = args.bpp
    ).to(device)
    decoder = Decoder(emb_step=args.emb_step, data_depth=args.bpp, log_size=args.log_size, msg_repeat=args.msg_repeat, wanway=True).to(device)
    g.load_state_dict(ckpt["g_ema"])
    decoder.load_state_dict(ckpt["decoder_ema"])
    # g = nn.DataParallel(g)
    # g.eval()
    # decoder.eval()


    if args.withmod:
        print("load msg mod.......")
        raise("mod is deprecated")
        if args.lasttwo:
            mod = MsgModulator(data_depth=2).to(device)
        else:
            mod = MsgModulator(data_depth=1).to(device)
        mod.load_state_dict(ckpt["mod_ema"])
        mod.eval()
    else:
        mod = None


    it = args.n_sample // args.batch + 1
    cnt = 0
    type_name = 'png'
    acc = 0
    for i in tqdm(range(it)):
        latent_z = torch.randn(args.batch, 512, device=device)

        ori_noise = g.make_noise(batch_size=args.batch)
        if args.lasttwo:
            finallayer_noise = torch.cat((ori_noise[args.emb_idx-1],ori_noise[args.emb_idx]),dim=1)
        else:
            finallayer_noise = ori_noise[args.emb_idx]
        # print(ori_noise[-1].shape)

        if mod is not None:
            mod_noise = mod(finallayer_noise)
            noise_sample, _ = g([latent_z], noise=ori_noise, randomize_noise=False,emb_secret=True, modeuated_noise=mod_noise)
        else:
            noise_sample, _ = g([latent_z], noise=ori_noise)

        # noise_sample, _ = g([latent_z], noise=ori_noise)
        # finallayer_noise = torch.randn(batch_size, bpp, img_size, img_size).to(device)
        # noise_sample, _ = g([latent_z], noise=ori_noise, emb_secret=True, modeuated_noise=finallayer_noise))
        




        
                    
        if args.attack:
        
            mod_finallayer_noise,msg_gt = attack_generate_modulated_noise_args(args.batch, device , args, msg_model=mod, ori_noise=finallayer_noise)
                    # print(mod_finallayer_noise)
            # print(mod_finallayer_noise.shape)
            # print(msg_gt.shape)
        else:
            # mod_finallayer_noise,msg_gt = old_generate_modulated_noise(args.batch, args.size, device, msg_model=mod, ori_noise=None, bpp=args.bpp)
            # mod_finallayer_noise,msg_gt = old_generate_modulated_noise(args.batch, args.size, device, msg_model=mod, ori_noise=ori_noise[-1], bpp=args.bpp)
            pass
            

        sec_sample, _ = g([latent_z], noise=ori_noise, emb_secret=True, modeuated_noise=mod_finallayer_noise)
        sub, rate = getdiff(noise_sample,sec_sample)
        print(sub)
        print(rate)

        fake_img = sec_sample.clone().detach()

        

        sec_sample = tensor_to_image(sec_sample)
        noise_sample = tensor_to_image(noise_sample)
        for j in range(sec_sample.shape[0]):
            stego = Image.fromarray(sec_sample[j, :, :, :])
            stego_path = os.path.join(args.out,"stego", str(cnt)+'.'+type_name)
            
            
            stego.save(stego_path)
            # stego.save(stego_path,quality=50)

            # re_img = Image.open(stego_path)
    
            # re_img = transform(re_img)
            # re_img = re_img.cuda()
            # re_img = re_img[None,:]

            cover = Image.fromarray(noise_sample[j, :, :, :])
            cover.save(os.path.join(args.out,"cover", str(cnt)+'.'+type_name))

            # res = noise_sample[j, :, :, :].astype(np.int)-sec_sample[j, :, :, :].astype(np.int)
            # res = np.abs(res)
            # s = np.sum(res)
            # print(res.shape[0]*res.shape[1]*res.shape[2])
            # av = s/(res.shape[0]*res.shape[1]*res.shape[2])
            # print(av)
            # b = np.max(res)
            # print(b)
            # residual = Image.fromarray(res)
            # residual.save(os.path.join(args.out,"residual", str(cnt)+'.'+type_name))
            cnt += 1

        # fake_img = torch.clamp(fake_img,-1,1)
        fake_img = torch.clamp(fake_img,-1,1)
        fake_img = torch.round(255.0 * (fake_img + 1.0) / 2.0)
            # print(torch.max(fake_img))
            # print(torch.min(fake_img))
        fake_img = fake_img / 127.5 - 1.0
        
        if args.attack:
            # t = pipeline(fake_img)
            fake_img = valid_pipeline(fake_img)
            # re_img = valid_pipeline(re_img,quan = True)
            # print(torch.sum(torch.abs(t-fake_img)))
            pass
        else:

            fake_img = torch.clamp(fake_img,-1,1)
            fake_img = torch.round(255.0 * (fake_img + 1.0) / 2.0)
            # print(torch.max(fake_img))
            # print(torch.min(fake_img))
            fake_img = fake_img / 127.5 - 1.0
        #decoder gradient
        # fake_image =  127.5 * (fake_image + 1.0)
        # noised_image = pipeline(fake_image)
        # print(torch.sum(torch.abs(re_img-fake_img)))
        # noised_image = noised_image / 127.5 - 1.0
        # print(re_img.shape)
        # re_img = re_img + torch.rand(1,3,128,128).cuda()*10
        # fake_img -= 0.5

        # print("real")
        # msg_asl = decoder(fake_img)
        # # print(msg_asl)

        # print("asl")
        msg_pred = decoder(fake_img) 
        # msg_pred = decoder(re_img) 
        # print(msg_pred)
        label = msg_gt>=0.5
        # print(msg_gt)
        # print(msg_pred)
        # print(msg_pred.shape)
        # print(msg_gt.shape)
        dec_acc = (msg_pred >= 0.0).eq(label).sum().float() / msg_gt.numel()
        print(dec_acc)
        acc += dec_acc
        if i % 1==0:
            print("accumu")
            print(acc/(i+1))
        