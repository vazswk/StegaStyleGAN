import argparse
import math
import os
os.environ['CUDA_VISIBLE_DEVICES'] = '2'
import torch
from torch import optim
from torch.nn import functional as F
from torchvision import transforms
from torch.nn.functional import binary_cross_entropy_with_logits
from PIL import Image
from tqdm import tqdm

import lpips
from old_ste_model import Decoder
from utils import *


from glob import glob


from torch.utils.data import Dataset
from torch.utils import data
    
class ZLatentDataset(Dataset):
    def __init__(self, data_path):
        self.data_path = data_path
        
        self.files_list = glob(os.path.join(self.data_path, '*.pt'))
        

    def __getitem__(self, idx):
        z_path = self.files_list[idx]
        
        z = torch.load(z_path)

        latent = z["latent"]
        noise = z["noise"]

        noises = []

        for no in noise:
            noises.append(no[0])


        return latent, noises

    def __len__(self):
        return len(self.files_list)
    
# loader = data.DataLoader(
#         dataset,
#         batch_size=args.batch,
#         sampler=data_sampler(dataset, shuffle=True, distributed=args.distributed),
#         drop_last=True,
#     )


def requires_grad(model, flag=True):
    for p in model.parameters():
        p.requires_grad = flag


def make_image(tensor):
    return (
        tensor.detach()
        .clamp_(min=-1, max=1)
        .add(1)
        .div_(2)
        .mul(255)
        .type(torch.uint8)
        .permute(0, 2, 3, 1)
        .to("cpu")
        .numpy()
    )

def sample_data(loader):
    while True:
        for batch in loader:
            yield batch


def getmsggt(noises):
    x = noises[-1].detach().clone()
    x[x>0] = 1
    x[x<0] = 0
    return x


if __name__ == "__main__":
    device = "cuda"

    parser = argparse.ArgumentParser(
        description="Image projector to the generator latent spaces"
    )
    parser.add_argument(
        "--ckpt", type=str, default=r"attack_bppn_model/checkpoint_celeba_jpeg75asl_msgrepeat1_emb5_dec0.7_bpp1_batch16_seed75_size128_jt_decayto0.7_wanway/370000.pt"
    )
    parser.add_argument(
        "--size", type=int, default=128, help="output image sizes of the generator"
    )
    parser.add_argument("--lr", type=float, default=0.002, help="learning rate")
    parser.add_argument(
        "--emb_step", type=int, default=7, help="  "
    )
    parser.add_argument("--step", type=int, default=30000, help="optimize iterations")
    parser.add_argument(
        "--w_plus",
        action="store_true",
        help="allow to use distinct latent codes to each layers",
    )
    parser.add_argument(
        "--files", type=str, default="small_invz", help=""
    )

    parser.add_argument(
        "--bpp", type=int, default=1, help=" bpp "
    )

    parser.add_argument(
        "--batch_size", type=int, default=2, help=" bpp "
    )
    parser.add_argument(
        "--attack",
        # type=bool,
        # default=True,
        action = "store_true",
        help="",
    )

    args = parser.parse_args()
    
    args.test = False
    args.wanway = True
    args.msg_repeat = 1
    args.lasttwo = False

    args.log_size = int(math.log(args.size, 2))
    
    if args.attack:
        from model_attack_bppn import Generator
    else:
        from model_lastone_bppn import Generator
    

    n_mean_latent = 10000

    resize = min(args.size, 256)

    transform = transforms.Compose(
        [
            transforms.Resize(resize),
            transforms.CenterCrop(resize),
            transforms.ToTensor(),
            transforms.Normalize([0.5, 0.5, 0.5], [0.5, 0.5, 0.5]),
        ]
    )

    

    # files = glob(os.path.join(args.files, "*"))
    # print(files)
    

    

    ckpt = torch.load(args.ckpt)


    


    if args.attack:
        g_ema = Generator(
            args.size, 512, 8, emb_step=args.emb_step, bpp=args.bpp
        )
    else:
        g_ema = Generator(args.size, 512, 8, bpp=args.bpp)
    

    decoder = Decoder(emb_step=args.emb_step, data_depth=args.bpp, log_size=args.log_size, msg_repeat=1, wanway=True).to(device)  #128 : 7
    


    g_optim = optim.Adam(
        g_ema.parameters(),
        lr=args.lr,
        betas=(0 , 0.99),
    )
    g_optim.add_param_group({'params': decoder.parameters(),
                     'lr': args.lr,
                     # 'mult': 0.1,
                    })


    g_ema.load_state_dict(ckpt["g_ema"], strict=False)
    g_ema.eval()
    g_ema = g_ema.to(device)

    requires_grad(g_ema,False)

    decoder.load_state_dict(ckpt["decoder_ema"])

    g_optim.load_state_dict(ckpt["g_optim"])

    dataset = ZLatentDataset(args.files)
    
    testdir = 'test_z'
    testset = ZLatentDataset(testdir)

    dataloader = data.DataLoader(dataset, batch_size=args.batch_size, shuffle=True, pin_memory=False, drop_last=True)
    test_dataloader = data.DataLoader(testset, batch_size=args.batch_size, shuffle=True, pin_memory=False, drop_last=True)

    loader = sample_data(dataloader)
    
    testloader = sample_data(test_dataloader)

    # percept = lpips.PerceptualLoss(
    #     model="net-lin", net="vgg", use_gpu=device.startswith("cuda")
    # )

    # noises_single = g_ema.make_noise(imgs.shape[0])
    # noises = []
    # for noise in noises_single:
    #     noises.append(noise.repeat(imgs.shape[0], 1, 1, 1).normal_())
    # print(noises[-1].shape)
    if args.bpp>1:
        raise("bpp > 1?????")


    pbar = tqdm(range(args.step))
    

    for i in pbar:

        latent, noises = next(loader)
        
        test_latent, test_noises = next(testloader)
        # latent = latent.to(device)
        # print(len(noise))
        # print(noise[0].shape)
        # noise = noise.to(device)
        
        # print(latent.shape)
        # print(noise.shape)

        # noise = g_ema.make_noise(args.batch_size)

        # img_gen, _ = g_ema([latent], input_is_latent=True, noise=noise)

        # batch, channel, height, width = img_gen.shape

        # t_noise, msg_gt = old_generate_modulated_noise(args.batch_size, 128, device, msg_model = None, ori_noise = final_noise, bpp=args.bpp)

        # print(noises[-1].shape)
        if args.attack:
            final_noise = noises[g_ema.emb_idx].detach().clone()
            t_noise, msg_gt = attack_generate_modulated_noise_args(args.batch_size, device, args, msg_model=None, ori_noise=final_noise)
        else:
            final_noise = noises[-1].detach().clone()
            t_noise, msg_gt = old_generate_modulated_noise(args.batch_size, 128, device, msg_model = None, ori_noise = final_noise, bpp=args.bpp)
        
        img_gen, _ = g_ema([latent], input_is_latent=True, noise=noises, emb_secret = True, modeuated_noise = t_noise)




        img_ar = make_image(img_gen)
        
        
        
        





        # img_gen, _ = g_ema([latent_in.detach()], input_is_latent=True, noise=noises, )
        # msg_gt = getmsggt(noises)
        

        # fake_img = img_gen.detach().clone()
        # fake_img = torch.round(255.0 * (fake_img + 1.0) / 2.0)
        # fake_img = fake_img / 127.5 - 1.0

        # msg_pred = decoder(fake_img)
        msg_pred = decoder(img_gen) 
        label = msg_gt>=0.5

        assert msg_gt.shape==msg_pred.shape
        
        # # print(msg_pred)
        dec_acc = (msg_pred >= 0.0).eq(label).sum().float() / msg_gt.numel()
        
        if i%500==0:
            # print(i)
            outdir = "haha_out_plus"
            if not os.path.exists(outdir):
                os.mkdir(outdir)
            for idx in range(args.batch_size):
                img_name = os.path.join(outdir,"project" + f"img{idx}_iter{i}_{round(float(dec_acc),4)}"+".png")
                pil_img = Image.fromarray(img_ar[idx])
                pil_img.save(img_name)


        dec_loss = binary_cross_entropy_with_logits(msg_pred, label.float())
        g_optim.zero_grad()
        dec_loss.backward()
        g_optim.step()
        
        
        if args.test:
        
            if args.attack:
                final_noise = test_noises[g_ema.emb_idx].detach().clone()
                t_noise, msg_gt = attack_generate_modulated_noise_args(args.batch_size, device, args, msg_model=None, ori_noise=final_noise)
            else:
                final_noise = test_noises[-1].detach().clone()
                t_noise, msg_gt = old_generate_modulated_noise(args.batch_size, 128, device, msg_model = None, ori_noise = final_noise, bpp=args.bpp)
            
            img_gen, _ = g_ema([test_latent], input_is_latent=True, noise=noises, emb_secret = True, modeuated_noise = t_noise)
            
            msg_pred = decoder(img_gen) 
            label = msg_gt>=0.5

            assert msg_gt.shape==msg_pred.shape
            
            # # print(msg_pred)
            valid_acc = (msg_pred >= 0.0).eq(label).sum().float() / msg_gt.numel()
        else:
            valid_acc = 0


        pbar.set_description(
            (
                # f"perceptual: {p_loss.item():.4f}; noise regularize: {n_loss.item():.4f};"
                f"test acc: {valid_acc:.4f};"
                f"train acc: {dec_acc:.4f}"
            )
        )

        # if i>args.starttrain and i%100==0:
        #     for tt in range(300000):
        #         t_noise, msg_gt = old_generate_modulated_noise(1, 128, device, msg_model = None, ori_noise = final_noise, bpp=args.bpp)
        #         img_gen, _ = g_ema([latent_in.detach()], input_is_latent=True, noise=noises, emb_secret = True, modeuated_noise = t_noise)

        #         # img_gen, _ = g_ema([latent_in.detach()], input_is_latent=True, noise=noises, )
        #         # msg_gt = getmsggt(noises)
                

        #         # fake_img = img_gen.detach().clone()
        #         # fake_img = torch.round(255.0 * (fake_img + 1.0) / 2.0)
        #         # fake_img = fake_img / 127.5 - 1.0

        #         # msg_pred = decoder(fake_img)
        #         msg_pred = decoder(img_gen) 
        #         label = msg_gt>=0.5

        #         assert msg_gt.shape==msg_pred.shape
                
        #         # # print(msg_pred)
        #         dec_acc = (msg_pred >= 0.0).eq(label).sum().float() / msg_gt.numel()
        #         if tt%20==0:
        #             print(dec_acc)
        #         dec_loss = binary_cross_entropy_with_logits(msg_pred, label.float())
        #         g_optim.zero_grad()
        #         dec_loss.backward()
        #         g_optim.step()




