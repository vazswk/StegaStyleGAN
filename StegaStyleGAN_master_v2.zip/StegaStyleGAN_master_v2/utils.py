import numpy as np
import os
import re
import csv
import time
import pickle
import logging

import torch
from torchvision import datasets, transforms
import torchvision.utils
from torch.utils import data
import torch.nn.functional as F

import torch.nn as nn

# def generate_modulated_noise(batch_size, noise_img_size, device, msg_model = None, ori_noise = None, bpp=1): # 用秘密信息调制噪声图
#     # noise = []
#     msg = torch.zeros(batch_size, bpp, noise_img_size, noise_img_size).random_(0, 2).to(device)
#     payload_step = msg * 2 - 1
#     if ori_noise is None:
#         ori_noise = torch.randn(batch_size, 1, noise_img_size, noise_img_size).to(device)
#     if bpp==2:
#         if ori_noise.shape[1]==1:
#             ori_noise = ori_noise.repeat(1,bpp,1,1)
#         else:
#             print("noise channel error")
#     ori_noise = torch.abs(ori_noise)
#     modeuated_noise = ori_noise.mul(payload_step)
#     if msg_model != None:
#         # print(" mod noise ...")
#         modeuated_noise = msg_model(modeuated_noise)
#     return modeuated_noise, msg



# def attack_generate_modulated_noise(batch_size, noise_img_size, device, msg_model = None, ori_noise = None, msg_size=64, lasttwo=False, msg_repeat=1, wanway=False): # 用秘密信息调制噪声图
#     # noise = []
#     msg_ori = torch.zeros(batch_size, 1, msg_size, msg_size*msg_repeat).random_(0, 2).to(device)
#     # if msg_size<noise_img_size:
    
#     # assert h_repeat==2
#     if not wanway:
#         h_repeat = int(noise_img_size/msg_ori.shape[2])
#         w_repeat = int(noise_img_size/msg_ori.shape[3])
#         msg = msg_ori.repeat(1,1,h_repeat, w_repeat)
#     else:
#         msg = msg_ori
#     # print(msg.shape)
#     payload_step = msg * 2 - 1
#     if ori_noise is None:
#         if lasttwo:
#             ori_noise = torch.randn(batch_size, 2, noise_img_size, noise_img_size).to(device)
#         else:
#             ori_noise = torch.randn(batch_size, 1, noise_img_size, noise_img_size).to(device)
    
#     if lasttwo:
#         assert ori_noise.shape[1] == 2
#     assert ori_noise.shape[2]==payload_step.shape[2]
#     assert ori_noise.shape[3]==payload_step.shape[3]

#     ori_noise = torch.abs(ori_noise)
#     modeuated_noise = ori_noise.mul(payload_step)
#     if msg_model != None:
#         # print(" mod noise ...")
#         modeuated_noise = msg_model(modeuated_noise)
#     return modeuated_noise, msg_ori




def attack_generate_modulated_noise_args(batch_size, device, args, msg_model = None, ori_noise = None): # 用秘密信息调制噪声图
    # noise = []
    msg_size = 2**(args.emb_step)
    if args.wanway:
        noise_img_size = msg_size
    else:
        noise_img_size = args.size

    if args.wanway:
        assert args.msg_repeat == 1

    msg_ori = torch.zeros(batch_size, args.bpp, msg_size, msg_size*args.msg_repeat).random_(0, 2).to(device)
    # if msg_size<noise_img_size:
    
    # assert h_repeat==2
    if not args.wanway:
        assert 1==0
        h_repeat = int(noise_img_size/msg_ori.shape[2])
        w_repeat = int(noise_img_size/msg_ori.shape[3])
        msg = msg_ori.repeat(1,1,h_repeat, w_repeat)
    else:
        msg = msg_ori
    # print(msg.shape)
    payload_step = msg * 2 - 1
    if ori_noise is None:
        if args.lasttwo:
            ori_noise = torch.randn(batch_size, 2, noise_img_size, noise_img_size).to(device)
        else:
            ori_noise = torch.randn(batch_size, args.bpp, noise_img_size, noise_img_size).to(device)
    
    if args.lasttwo:
        assert ori_noise.shape[1] == 2
    assert ori_noise.shape[2]==payload_step.shape[2]
    assert ori_noise.shape[3]==payload_step.shape[3]

    ori_noise = torch.abs(ori_noise)
    modeuated_noise = ori_noise.mul(payload_step)
    if msg_model != None:
        # print(" mod noise ...")
        modeuated_noise = msg_model(modeuated_noise)
    return modeuated_noise, msg_ori




def old_generate_modulated_noise(batch_size, noise_img_size, device, msg_model = None, ori_noise = None, bpp=1): # 用秘密信息调制噪声图
    # noise = []
    msg = torch.zeros(batch_size, bpp, noise_img_size, noise_img_size).random_(0, 2).to(device)
    payload_step = msg * 2 - 1
    if ori_noise is None:
        ori_noise = torch.randn(batch_size, bpp, noise_img_size, noise_img_size).to(device)
    # if bpp==2:
    #     if ori_noise.shape[1]==1:
    #         ori_noise = ori_noise.repeat(1,bpp,1,1)
    #     else:
    #         print("noise channel error")
    ori_noise = torch.abs(ori_noise)
    assert ori_noise.shape[1]==payload_step.shape[1]  # 尺寸不一致时出发异常
    modeuated_noise = ori_noise.mul(payload_step)
    # print(modeuated_noise.shape)
    if msg_model != None:
        # print(" mod noise ...")
        modeuated_noise = msg_model(modeuated_noise)
    return modeuated_noise, msg



def old_generate_01(batch_size, noise_img_size, device, msg_model = None, ori_noise = None, bpp=1): # 用秘密信息调制噪声图
    # noise = []
    msg = torch.zeros(batch_size, bpp, noise_img_size, noise_img_size).random_(0, 2).to(device)
    # payload_step = msg * 2 - 1
    # if ori_noise is None:
        # ori_noise = torch.randn(batch_size, bpp, noise_img_size, noise_img_size).to(device)
    # if bpp==2:
    #     if ori_noise.shape[1]==1:
    #         ori_noise = ori_noise.repeat(1,bpp,1,1)
    #     else:
    #         print("noise channel error")
    # ori_noise = torch.abs(ori_noise)
    # assert ori_noise.shape[1]==payload_step.shape[1]
    modeuated_noise = msg.detach().clone()
    # print(modeuated_noise.shape)
    if msg_model != None:
        # print(" mod noise ...")
        modeuated_noise = msg_model(modeuated_noise)
    return modeuated_noise, msg



def bonuli_test(batch_size, noise_img_size, device, msg_model = None, ori_noise = None, bpp=1, prob=0.45): # 用秘密信息调制噪声图
    # noise = []
    # msg = torch.zeros(batch_size, bpp, noise_img_size, noise_img_size).random_(0, 2).to(device)
    pmap = torch.zeros(batch_size, bpp, noise_img_size, noise_img_size).to(device)
    pmap += prob
    msg = torch.bernoulli(pmap)
    # print(torch.sum(msg)/pmap.numel())
    payload_step = msg * 2 - 1
    if ori_noise is None:
        ori_noise = torch.randn(batch_size, bpp, noise_img_size, noise_img_size).to(device)
    # if bpp==2:
    #     if ori_noise.shape[1]==1:
    #         ori_noise = ori_noise.repeat(1,bpp,1,1)
    #     else:
    #         print("noise channel error")
    ori_noise = torch.abs(ori_noise)
    assert ori_noise.shape[1]==payload_step.shape[1]
    modeuated_noise = ori_noise.mul(payload_step)
    # print(modeuated_noise.shape)
    if msg_model != None:
        # print(" mod noise ...")
        modeuated_noise = msg_model(modeuated_noise)
    return modeuated_noise, msg


def unnormalize(x):
    x = torch.clamp(x,-1,1)
    x = torch.round(255.0 * (x + 1.0) / 2.0)
    return x

def getdiff(cover, stego):
    cover = unnormalize(cover).int()
    stego = unnormalize(stego).int()
    sub = torch.mean(torch.abs(cover-stego).float())
    # print(sub)
    change = 1 - torch.sum(cover==stego) / cover.numel()
    # print(change)
    return sub, change



y_table = np.array(
    [[16, 11, 10, 16, 24, 40, 51, 61], [12, 12, 14, 19, 26, 58, 60,
                                        55], [14, 13, 16, 24, 40, 57, 69, 56],
     [14, 17, 22, 29, 51, 87, 80, 62], [18, 22, 37, 56, 68, 109, 103,
                                        77], [24, 35, 55, 64, 81, 104, 113, 92],
     [49, 64, 78, 87, 103, 121, 120, 101], [72, 92, 95, 98, 112, 100, 103, 99]],
    dtype=np.float32).T

y_table = nn.Parameter(torch.from_numpy(y_table)).cuda()
#
c_table = np.empty((8, 8), dtype=np.float32)
c_table.fill(99)
c_table[:4, :4] = np.array([[17, 18, 24, 47], [18, 21, 26, 66],
                            [24, 26, 56, 99], [47, 66, 99, 99]]).T
c_table = nn.Parameter(torch.from_numpy(c_table)).cuda()