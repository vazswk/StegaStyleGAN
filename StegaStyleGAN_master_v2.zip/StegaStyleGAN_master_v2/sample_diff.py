# sample_diff.py  ： 同一个z，相同的噪声，生成不同信息嵌入的图片
import argparse
import math
import random
import os
import pickle
os.environ['CUDA_VISIBLE_DEVICES'] = '0'
import numpy as np
import torch
from torch import nn, autograd, optim
from torch.nn import functional as F
from torch.utils import data
import torch.distributed as dist
from torchvision import transforms, utils
from tqdm import tqdm
from torch.nn.functional import binary_cross_entropy_with_logits

from op import conv2d_gradfix

import numpy as np
import torch

from old_ste_model import Decoder, MsgModulator
from PIL import Image

from utils import *

from noise_layers.noiser import Noiser, Identity, JpegCompression, ASLJPEG, REALJPEG



transform = transforms.Compose(
        [
            
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5), inplace=True),
        ]
    )


def tensor_to_image(tensor):
    """
    Transforms a torch tensor into numpy uint8 array (image)
    :param tensor: (batch_size x channels x height x width) torch tensor in range [-1.0, 1.0]
    :return: (batch_size x height x width x channels) uint8 array
    """
    image = tensor.permute(0, 2, 3, 1).detach().cpu().numpy()
    image = (image + 1.) * 127.5
    return np.clip(image, 0, 255).astype(np.uint8)


def sample2path(g_ema, n_sample, path, batch_size, device, latent_size, type='jpg'):
    #将载密位图生成到目标目录，保存为相应格式
    cnt = 0
    for idx in tqdm(range(n_sample//batch_size)):

        sample_z = torch.randn(batch_size, latent_size, device=device)
        g_ema.eval()
        sample, _ = g_ema([sample_z])
        


# def generate_modulated_noise(batch_size, img_size, device, msg_model = None, ori_noise = None): # 用秘密信息调制噪声图
#     # noise = []
#     msg = torch.zeros(batch_size, 1, img_size, img_size).random_(0, 2).to(device)
#     payload_step = msg * 2 - 1
#     if ori_noise is None:
#         ori_noise = torch.randn(batch_size, 1, img_size, img_size).to(device)
#     ori_noise = torch.abs(ori_noise)
#     modeuated_noise = ori_noise.mul(payload_step)
#     if msg_model != None:
#         print(" mod noise ...")
#         modeuated_noise = msg_model(modeuated_noise)
#     return modeuated_noise, msg


# def generate_modulated_noise(batch_size, img_size, device, msg_model = None, ori_noise = None, bpp=1): # 用秘密信息调制噪声图
#     # noise = []
#     msg = torch.zeros(batch_size, bpp, img_size, img_size).random_(0, 2).to(device)
#     payload_step = msg * 2 - 1
#     if ori_noise is None:
#         ori_noise = torch.randn(batch_size, 1, img_size, img_size).to(device)
#     if bpp==2:
#         if ori_noise.shape[1]==1:
#             ori_noise = ori_noise.repeat(1,bpp,1,1)
#         else:
#             print("noise channel error")
#     print(ori_noise.shape[1])
#     ori_noise = torch.abs(ori_noise)
#     modeuated_noise = ori_noise.mul(payload_step)
#     if msg_model != None:
#         # print(" mod noise ...")
#         modeuated_noise = msg_model(modeuated_noise)
#     return modeuated_noise, msg

def make_noise(batch, latent_dim, n_noise, device):
    if n_noise == 1:
        return torch.randn(batch, latent_dim, device=device)

    noises = torch.randn(n_noise, batch, latent_dim, device=device).unbind(0)

    return noises


def mixing_noise(batch, latent_dim, prob, device):
    if prob > 0 and random.random() < prob:
        return make_noise(batch, latent_dim, 2, device)

    else:
        return [make_noise(batch, latent_dim, 1, device)]
    
    
    
    
    
    

def gen_img(g, mod, decoder, args, latent_z, inject_idx, file_name):
    
    ori_noise = g.make_noise(batch_size=args.batch)
    if args.lasttwo:
        finallayer_noise = torch.cat((ori_noise[-2],ori_noise[-1]),dim=1)
    else:
        finallayer_noise = ori_noise[-1]
    # print(ori_noise[-1].shape)

    if mod is not None:
        mod_noise = mod(finallayer_noise)
        noise_sample, _ = g(latent_z, noise=ori_noise, randomize_noise=False,emb_secret=True, modeuated_noise=mod_noise)
    else:
        noise_sample, _ = g(latent_z, inject_index=inject_idx, noise=ori_noise)

    # noise_sample, _ = g([latent_z], noise=ori_noise)
    # finallayer_noise = torch.randn(batch_size, bpp, img_size, img_size).to(device)
    # noise_sample, _ = g([latent_z], noise=ori_noise, emb_secret=True, modeuated_noise=finallayer_noise))

    t_sample = 4
                
    if args.attack:
        mod_finallayer_noise,msg_gt = attack_generate_modulated_noise(args.batch, args.size, device, msg_model=mod, ori_noise=finallayer_noise, msg_size=2**(args.emb_step), lasttwo=args.lasttwo, msg_repeat=args.msg_repeat)
                # print(mod_finallayer_noise)
        # print(mod_finallayer_noise.shape)
        # print(msg_gt.shape)
    else:
        # mod_finallayer_noise,msg_gt = old_generate_modulated_noise(args.batch, args.size, device, msg_model=mod, ori_noise=None, bpp=args.bpp)
        # mod_finallayer_noise,msg_gt = old_generate_01(args.batch, args.size, device, msg_model=mod, ori_noise=ori_noise[-1], bpp=args.bpp)
        mod_finallayer_noise0,msg_gt0 = old_generate_modulated_noise(args.batch, args.size, device, msg_model=mod, ori_noise=finallayer_noise, bpp=args.bpp)
        mod_finallayer_noise1,msg_gt1 = old_generate_modulated_noise(args.batch, args.size, device, msg_model=mod, ori_noise=finallayer_noise, bpp=args.bpp)
        mod_finallayer_noise2,msg_gt2 = old_generate_modulated_noise(args.batch, args.size, device, msg_model=mod, ori_noise=finallayer_noise, bpp=args.bpp)
        mod_finallayer_noise3,msg_gt3 = old_generate_modulated_noise(args.batch, args.size, device, msg_model=mod, ori_noise=finallayer_noise, bpp=args.bpp)
    

    # mod_finallayer_noise = torch.cat([mod_finallayer_noise0,mod_finallayer_noise1,mod_finallayer_noise2,mod_finallayer_noise3],dim=0)
    
    # tz = latent_z[0].repeat(t_sample, 1)
        
    
    sec_sample0, _ = g(latent_z, inject_index=inject_idx, noise=ori_noise, emb_secret=True, modeuated_noise=mod_finallayer_noise0)
    sec_sample1, _ = g(latent_z, inject_index=inject_idx, noise=ori_noise, emb_secret=True, modeuated_noise=mod_finallayer_noise1)
    sec_sample2, _ = g(latent_z, inject_index=inject_idx, noise=ori_noise, emb_secret=True, modeuated_noise=mod_finallayer_noise2)
    sec_sample3, _ = g(latent_z, inject_index=inject_idx, noise=ori_noise, emb_secret=True, modeuated_noise=mod_finallayer_noise3)
    
    sec_sample = [sec_sample0,sec_sample1,sec_sample2,sec_sample3]
    msg_gt_list = [msg_gt0,msg_gt1,msg_gt2,msg_gt3]
    # sub, rate = getdiff(noise_sample,sec_sample)
    # print(sub)
    # print(rate)

    
    
    # fake_img = fake_img[0]

    type_name = 'png'

    # sec_sample = tensor_to_image(sec_sample)
    
        

    
    noise_sample = tensor_to_image(noise_sample)
    cover = Image.fromarray(noise_sample[0, :, :, :])
    cover.save(os.path.join(args.real_out, f'cover'+'.'+type_name))


    for j in range(len(sec_sample)):
        
        fake_img = sec_sample[j].clone().detach()
        msg_gt = msg_gt_list[j]
        
        
        fake_img = torch.clamp(fake_img,-1,1)
        fake_img = torch.round(255.0 * (fake_img + 1.0) / 2.0)
        # print(torch.max(fake_img))
        # print(torch.min(fake_img))
        fake_img = fake_img / 127.5 - 1.0

        msg_pred = decoder(fake_img) 
        # print(msg_pred)
        label = msg_gt>=0.5
        
        assert msg_gt.shape==msg_pred.shape
        dec_acc = (msg_pred >= 0.0).eq(label).sum().float() / msg_gt.numel()
        print("dec acc:", dec_acc)

        
        np_fake = tensor_to_image(fake_img)
        
        stego = Image.fromarray(np_fake[0])
        stego_path = os.path.join(args.real_out,f"stego{j}_acc_{round(float(dec_acc),4)}"+'.'+type_name)
        stego.save(stego_path)
        # stego.save(stego_path,quality=65)

        # re_img = Image.open(stego_path)

        # re_img = transform(re_img)
        # re_img = re_img.cuda()
        # re_img = re_img[None,:]

        

        res = noise_sample[0, :, :, :].astype(np.int32)-np_fake[0].astype(np.int32)
        # print(np.max(res))
        # print(np.min(res))
        res = np.abs(res) * 5
        res = np.clip(res, 0, 255)
        
        res = res.astype(np.uint8)
        # print(np.sum(res)/128/128/3)
        # print(res.shape)
        # s = np.sum(res)
        # print(res.shape[0]*res.shape[1]*res.shape[2])
        # av = s/(res.shape[0]*res.shape[1]*res.shape[2])
        # print(av)
        # b = np.max(res)
        # print(b)
        residual = Image.fromarray(res)
        residual.save(os.path.join(args.real_out,f"residual_{j}"+'.'+type_name))
        # cnt += 1

    # fake_img = torch.clamp(fake_img,-1,1)
    
    
    
    

def setup_seed(seed=99):
    torch.manual_seed(seed)  # 为CPU设置随机种子
    np.random.seed(seed)  # Numpy module.
    random.seed(seed)  # Python random module.
    if torch.cuda.is_available():
        # torch.backends.cudnn.benchmark = False
        torch.backends.cudnn.deterministic = True
        torch.cuda.manual_seed(seed)  # 为当前GPU设置随机种子
        torch.cuda.manual_seed_all(seed)  # 为所有GPU设置随机种子
        #os.environ['PYTHONHASHSEED'] = str(seed)

    



if __name__ == "__main__":
    device = "cuda"

    parser = argparse.ArgumentParser(description="sample to path")

    parser.add_argument(
        "--ckpt",
        type=str,
        default=r"checkpoint_celeba_new_bpp1_dec0.15_batch4_seed75_jt_decayto0.15_128/585000.pt"
    )
    # checkpoint_celebhq_seed35_batch12_nojingtiao_oriseed35_continue_128\250000.pt

    parser.add_argument(
        "--out",
        type=str,
        default=r"./test"
    )

    parser.add_argument(
        "--size", type=int, default=128, help="image sizes for generator"
    )

    parser.add_argument(
        "--n_sample", type=int, default=10000
    )

    parser.add_argument(
        "--batch", type=int, default=1
    )

    parser.add_argument(
        "--emb_step", type=int, default=7
    )

    parser.add_argument(
        "--bpp", type=int, default=1
    )
    parser.add_argument(
        "--withmod",
        # type=bool,
        # default=True,
        action = "store_true",
        help="msg ",
    )
    parser.add_argument(
        "--attack",
        # type=bool,
        # default=True,
        action = "store_true",
        help="msg ",
    )
    parser.add_argument(
        "--lasttwo",
        # type=bool,
        # default=True,
        action = "store_true",
        help="msg ",
    )
    parser.add_argument(
        "--msg_repeat", type=int, default=1
    )

    valid_pipeline = Noiser(noise_layers=[REALJPEG(height=32, width=32, quality=50)], device='cuda') #验证时的信道噪声模拟模块
    pipeline = Noiser(noise_layers=['ASLJpeg'], device='cuda') #验证时的信道噪声模拟模块

    args = parser.parse_args()
    args.log_size = int(math.log(args.size, 2))
    if not os.path.exists(os.path.join(args.out)):
        os.makedirs(os.path.join(args.out))
    
    if not os.path.exists(os.path.join(args.out,"cover")):
        os.mkdir(os.path.join(args.out,"cover"))
    if not os.path.exists(os.path.join(args.out,"stego")):
        os.mkdir(os.path.join(args.out,"stego"))
    # if not os.path.exists(os.path.join(args.out,"residual")):
    #     os.mkdir(os.path.join(args.out,"residual"))
    

    setup_seed(97)


    # if args.bpp == 1:
    #     if args.lasttwo:
    #         print("load model lasttwo")
    #         from model_lasttwo import Generator, Discriminator
    #     else:
    #         print("load model lastone")
    #         from model_lastone import Generator, Discriminator
    # elif args.bpp==2:
        
    #         print("load model with way2 bpp2")
    #         from model_lastone_bpp2 import Generator, Discriminator

    from model_mixing import Generator, Discriminator

    ckpt = torch.load(args.ckpt)

    g = Generator(args.size, 512, 8, bpp=args.bpp).to(device)
    decoder = Decoder(emb_step=args.emb_step, data_depth=args.bpp, log_size=args.log_size, msg_repeat=args.msg_repeat).to(device)
    g.load_state_dict(ckpt["g_ema"])
    decoder.load_state_dict(ckpt["decoder_ema"])
    # g = nn.DataParallel(g)
    # g.eval()
    # decoder.eval()
    
    assert args.batch==1


    if args.withmod:
        print("load msg mod.......")
        if args.lasttwo:
            mod = MsgModulator(data_depth=2).to(device)
        else:
            mod = MsgModulator(data_depth=args.bpp).to(device)
        mod.load_state_dict(ckpt["mod_ema"])
        mod.eval()
    else:
        mod = None


    it = 100
    cnt = 0
    type_name = 'png'
    acc = 0

    # tz0 = torch.load("0.pt")
    
    # tzs = []
    # tz_idxs = [27,2,3,25,17,1,4,12,13,26]
    # for tz_idx in tz_idxs:
    #     tzs.append(torch.load(f"zlatent/{tz_idx}.pt"))
        
    # szs = []
    # sz_idxs = [6,8,10,11,15,18,19,20,21,22,24]
    
    # for sz_idx in sz_idxs:
    #     szs.append(torch.load(f"zlatent/{sz_idx}.pt"))
    

    for i in tqdm(range(0,50)):
        # latent_z = torch.randn(args.batch, 512, device=device)
        
        if not os.path.exists(os.path.join(args.out,f"iter_{i}")):
            os.mkdir(os.path.join(args.out,f"iter_{i}"))
        args.real_out = os.path.join(args.out,f"iter_{i}")
        # args.real_out = args.out
        # if not os.path.exists(os.path.join(args.real_out,f"cover")):
        #     os.mkdir(os.path.join(args.real_out,f"cover"))
        # if not os.path.exists(os.path.join(args.real_out,f"stego")):
        #     os.mkdir(os.path.join(args.real_out,f"stego"))          
            
        
        latent_z0 = make_noise(args.batch, 512, 1, device)
        
        # latent_z1 = make_noise(args.batch, 512, 1, device)
        
        
        # sz = szs[i]
        gen_img(g,mod,decoder,args,[latent_z0],0,'')

        # torch.save(latent_z0,os.path.join(args.real_out,f"z{i}.pt"))
        
        # for j in range(0,len(tzs)):
        #     tz = tzs[j]
            
        #     gen_img(g,mod,decoder,args,[tz],0,f'tz_{j}')
            
        #     gen_img(g,mod,decoder,args,[sz,tz],0,f'tz_{j}_inj{0}')
        #     gen_img(g,mod,decoder,args,[sz,tz],1,f'tz_{j}_inj{1}')
        #     gen_img(g,mod,decoder,args,[sz,tz],2,f'tz_{j}_inj{2}')
        #     gen_img(g,mod,decoder,args,[sz,tz],3,f'tz_{j}_inj{3}')
        #     gen_img(g,mod,decoder,args,[sz,tz],4,f'tz_{j}_inj{4}')
        #     gen_img(g,mod,decoder,args,[sz,tz],5,f'tz_{j}_inj{5}')
        #     gen_img(g,mod,decoder,args,[sz,tz],6,f'tz_{j}_inj{6}')
        #     gen_img(g,mod,decoder,args,[sz,tz],7,f'tz_{j}_inj{7}')
        #     gen_img(g,mod,decoder,args,[sz,tz],8,f'tz_{j}_inj{8}')
            # gen_img(g,mod,decoder,args,[sz,tz],8,f'tz_{j}_inj{8}')
            
        
        # torch.save(latent_z0,os.path.join(args.real_out,f"z0.pt"))
        # torch.save(latent_z1,os.path.join(args.real_out,f"z1.pt"))
        
        # for inj_idx in range(1,9):
        #     gen_img(g,mod,decoder,args,[latent_z0,latent_z1],inj_idx,f'mix_{inj_idx}')
        
        

        
        
        
        # acc += dec_acc
        # if i % 1==0:
        #     print("accumu", acc/(i))

        