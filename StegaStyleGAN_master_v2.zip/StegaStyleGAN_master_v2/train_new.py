import argparse
import math
import random
import os
import pickle

import warnings

os.environ['CUDA_VISIBLE_DEVICES'] = '0'

import numpy as np
import torch
from torch import nn, autograd, optim
from torch.nn import functional as F
from torch.utils import data
import torch.distributed as dist
from torchvision import transforms, utils
from tqdm import tqdm
from torch.nn.functional import binary_cross_entropy_with_logits
from noise_layers.noiser import Noiser, Identity, JpegCompression
from fid import calc_fid, calc_mu_sigma_from_stego_samples

try:
    import wandb

except ImportError:
    wandb = None


from dataset import MultiResolutionDataset
from distributed import (
    get_rank,
    synchronize,
    reduce_loss_dict,
    reduce_sum,
    get_world_size,
)
from op import conv2d_gradfix
from non_leaking import augment, AdaptiveAugment
from old_ste_model import MsgModulator, Decoder

from utils import *

def log_2_file(path, text):
    with open(path, 'a') as f:
        f.writelines(text + '\n')


def data_sampler(dataset, shuffle, distributed):
    if distributed:
        return data.distributed.DistributedSampler(dataset, shuffle=shuffle)

    if shuffle:
        return data.RandomSampler(dataset)

    else:
        return data.SequentialSampler(dataset)


def requires_grad(model, flag=True):
    for p in model.parameters():
        p.requires_grad = flag


def accumulate(model1, model2, decay=0.999):
    par1 = dict(model1.named_parameters())
    par2 = dict(model2.named_parameters())

    for k in par1.keys():
        par1[k].data.mul_(decay).add_(par2[k].data, alpha=1 - decay)  # par1 * decay + par2 * (1 - decay) ?


def sample_data(loader):
    while True:
        for batch in loader:
            yield batch    # next(sample_data) ；  yield 类似于return，但是是逐个连续返回结果，一直在线，不会退出


def d_logistic_loss(real_pred, fake_pred):
    real_loss = F.softplus(-real_pred)
    fake_loss = F.softplus(fake_pred)

    return real_loss.mean() + fake_loss.mean()


def d_r1_loss(real_pred, real_img):
    with conv2d_gradfix.no_weight_gradients():
        grad_real, = autograd.grad(
            outputs=real_pred.sum(), inputs=real_img, create_graph=True
        )
    grad_penalty = grad_real.pow(2).reshape(grad_real.shape[0], -1).sum(1).mean()

    return grad_penalty


def g_nonsaturating_loss(fake_pred):
    loss = F.softplus(-fake_pred).mean()

    return loss


def g_path_regularize(fake_img, latents, mean_path_length, decay=0.01):
    noise = torch.randn_like(fake_img) / math.sqrt(
        fake_img.shape[2] * fake_img.shape[3]
    )
    grad, = autograd.grad(
        outputs=(fake_img * noise).sum(), inputs=latents, create_graph=True
    )
    path_lengths = torch.sqrt(grad.pow(2).sum(2).mean(1))

    path_mean = mean_path_length + decay * (path_lengths.mean() - mean_path_length)

    path_penalty = (path_lengths - path_mean).pow(2).mean()

    return path_penalty, path_mean.detach(), path_lengths


def make_noise(batch, latent_dim, n_noise, device):    # 生成噪声
    if n_noise == 1:
        return torch.randn(batch, latent_dim, device=device)

    noises = torch.randn(n_noise, batch, latent_dim, device=device).unbind(0)

    return noises


def mixing_noise(batch, latent_dim, prob, device):     # 风格混合
    if prob > 0 and random.random() < prob:
        return make_noise(batch, latent_dim, 2, device)

    else:
        return [make_noise(batch, latent_dim, 1, device)]


def set_grad_none(model, targets):
    for n, p in model.named_parameters():
        if n in targets:
            p.grad = None


# def generate_modulated_noise(batch_size, img_size, device, msg_model = None, ori_noise = None): # 用秘密信息调制噪声图
#     # noise = []
#     msg = torch.zeros(batch_size, 1, img_size, img_size).random_(0, 2).to(device)
#     payload_step = msg * 2 - 1
#     if ori_noise is None:
#         ori_noise = torch.randn(batch_size, 1, img_size, img_size).to(device)
#     ori_noise = torch.abs(ori_noise)
#     modeuated_noise = ori_noise.mul(payload_step)
#     if msg_model != None:
#         print(" mod noise ...")
#         modeuated_noise = msg_model(modeuated_noise)
#     return modeuated_noise, msg

# def generate_modulated_noise(batch_size, img_size, device, msg_model = None, ori_noise = None, bpp=1): # 用秘密信息调制噪声图
#     # noise = []
#     msg = torch.zeros(batch_size, bpp, img_size, img_size).random_(0, 2).to(device)
#     payload_step = msg * 2 - 1
#     if ori_noise is None:
#         ori_noise = torch.randn(batch_size, 1, img_size, img_size).to(device)
#     if bpp==2:
#         if ori_noise.shape[1]==1:
#             ori_noise = ori_noise.repeat(1,bpp,1,1)
#         else:
#             print("noise channel error")
#     ori_noise = torch.abs(ori_noise)
#     modeuated_noise = ori_noise.mul(payload_step)
#     if msg_model != None:
#         # print(" mod noise ...")
#         modeuated_noise = msg_model(modeuated_noise)
#     return modeuated_noise, msg


def train(args, loader, generator, discriminator, decoder, mod, g_optim, d_optim, ste_optim, g_ema, decoder_ema, mod_ema, device):

    loader = sample_data(loader)

    print_flag = False
    pbar = range(args.iter)

    if get_rank() == 0:  # 限制操作只会在进程0中执行，避免多卡时重复
        pbar = tqdm(pbar, initial=args.start_iter, dynamic_ncols=True, smoothing=0.01)

    mean_path_length = 0

    d_loss_val = 0
    r1_loss = torch.tensor(0.0, device=device)
    g_loss_val = 0
    path_loss = torch.tensor(0.0, device=device)
    path_lengths = torch.tensor(0.0, device=device)
    mean_path_length_avg = 0
    loss_dict = {}

    if args.distributed:
        g_module = generator.module
        d_module = discriminator.module
        decoder_module = decoder.module
    else:
        g_module = generator
        d_module = discriminator
        decoder_module = decoder

    accum = 0.5 ** (32 / (10 * 1000))
    ada_aug_p = args.augment_p if args.augment_p > 0 else 0.0
    r_t_stat = 0

    if args.augment and args.augment_p == 0:
        ada_augment = AdaptiveAugment(args.ada_target, args.ada_length, 8, device)

    sample_z = torch.randn(args.n_sample, args.latent, device=device)
    valid_dec_acc = 0
    avg_sub = 0
    avg_change = 0

    for idx in pbar:
        i = idx + args.start_iter

        if i > args.iter:
            print("Done!")

            break

        real_img = next(loader)     # 逐个batch取样本： 用的是yield
        real_img = real_img.to(device)

        requires_grad(generator, False)
        if mod is not None:
            # print("mod is not none")
            requires_grad(mod, False)
        requires_grad(discriminator, True)

        noise = mixing_noise(args.batch, args.latent, args.mixing, device)

        if args.ganwithnoise:
            info_noise, _ = old_generate_modulated_noise(args.batch, 
                args.size, device , msg_model=mod, bpp=args.bpp)
            fake_img, _ = generator(noise, randomize_noise=True, emb_secret=True, modeuated_noise=info_noise)
        else:
            fake_img, _ = generator(noise)

        # fake_img, _ = generator(noise)



        if args.augment:
            print("aug is turned on......")
            real_img_aug, _ = augment(real_img, ada_aug_p)
            fake_img, _ = augment(fake_img, ada_aug_p)

        else:
            real_img_aug = real_img

        fake_pred = discriminator(fake_img)
        real_pred = discriminator(real_img_aug)
        d_loss = d_logistic_loss(real_pred, fake_pred)

        loss_dict["d"] = d_loss
        loss_dict["real_score"] = real_pred.mean()
        loss_dict["fake_score"] = fake_pred.mean()

        discriminator.zero_grad()
        d_loss.backward()
        d_optim.step()

        if args.augment and args.augment_p == 0:
            ada_aug_p = ada_augment.tune(real_pred)
            r_t_stat = ada_augment.r_t_stat

        d_regularize = i % args.d_reg_every == 0

        if d_regularize:
            real_img.requires_grad = True

            if args.augment:
                real_img_aug, _ = augment(real_img, ada_aug_p)

            else:
                real_img_aug = real_img

            real_pred = discriminator(real_img_aug)
            r1_loss = d_r1_loss(real_pred, real_img)
  
            discriminator.zero_grad()
            (args.r1 / 2 * r1_loss * args.d_reg_every + 0 * real_pred[0]).backward()

            d_optim.step()

        loss_dict["r1"] = r1_loss

        requires_grad(generator, True)
        if mod is not None:
            # print("mod is not none")
            requires_grad(mod, True)
        requires_grad(discriminator, False)

        noise = mixing_noise(args.batch, args.latent, args.mixing, device)

        if args.ganwithnoise:
            info_noise, _ = old_generate_modulated_noise(args.batch, 
                args.size, device , msg_model=mod, bpp=args.bpp)
            fake_img, _ = generator(noise, randomize_noise=True, emb_secret=True, modeuated_noise=info_noise)
        else:
            fake_img, _ = generator(noise)

        # fake_img, _ = generator(noise)

        if args.augment:
            fake_img, _ = augment(fake_img, ada_aug_p)

        fake_pred = discriminator(fake_img)
        g_loss = g_nonsaturating_loss(fake_pred)

        loss_dict["g"] = g_loss

        if mod is not None:
            mod.zero_grad()
        generator.zero_grad()
        g_loss.backward()
        g_optim.step()

        g_regularize = i % args.g_reg_every == 0

        if g_regularize:
            path_batch_size = max(1, args.batch // args.path_batch_shrink)
            noise = mixing_noise(path_batch_size, args.latent, args.mixing, device)

            if args.ganwithnoise:
                info_noise, _ = old_generate_modulated_noise(path_batch_size, 
                    args.size, device , msg_model=mod, bpp=args.bpp)
                fake_img, latents = generator(noise, return_latents=True, randomize_noise=True, emb_secret=True, modeuated_noise=info_noise)
            else:
                fake_img, latents = generator(noise, return_latents=True, emb_secret=False)

            # fake_img, latents = generator(noise, return_latents=True, emb_secret=False)

            path_loss, mean_path_length, path_lengths = g_path_regularize(
                fake_img, latents, mean_path_length
            )

            if mod is not None:
                mod.zero_grad()
            generator.zero_grad()
            weighted_path_loss = args.path_regularize * args.g_reg_every * path_loss

            if args.path_batch_shrink:
                weighted_path_loss += 0 * fake_img[0, 0, 0, 0]

            weighted_path_loss.backward()

            g_optim.step()

            mean_path_length_avg = (
                reduce_sum(mean_path_length).item() / get_world_size()
            )

        loss_dict["path"] = path_loss
        loss_dict["path_length"] = path_lengths.mean()


        if args.freeze:
            if not print_flag:
                print_flag = True
                print("freeze some param")
                print("warning!!!!   only work for 128 size")
            requires_grad(generator, False)
            for name, pa in g_module.named_parameters():
            # print(name)
                if 'convs.8' in name or 'convs.9' in name or 'to_rgbs.4' in name:
                    # print(name)
                    pa.requires_grad = True


        # 联合训练G 和 D 和 MSG
        noise = mixing_noise(args.batch, args.latent, args.mixing, device)
        modeuated_noise, msg_gt = old_generate_modulated_noise(args.batch, args.size, device , msg_model=mod, bpp=args.bpp)
        fake_img, _ = generator(noise, emb_secret=True, modeuated_noise=modeuated_noise)
        #decoder gradient
        # fake_image =  127.5 * (fake_image + 1.0)
        # noised_image = pipeline(fake_image)

        # fake_img = torch.round(255.0 * (fake_img + 1.0) / 2.0)
        # fake_img = fake_img / 127.5 - 1.0

        noised_image = fake_img
        
        # noised_image = noised_image / 127.5 - 1.0
        msg_pred = decoder(noised_image) # 解码器里如发现图尺寸不等于128将进行插值，得到128的图
        label = msg_gt>=0.5
        # print(msg_gt)
        dec_loss = binary_cross_entropy_with_logits(msg_pred, label.float())
        # print(msg_pred)
        # print((msg_pred >= 0.0).eq(label).sum().float())
        # print(msg_gt.numel())
        dec_acc = (msg_pred >= 0.0).eq(label).sum().float() / msg_gt.numel()
        dec_loss = args.dec_weight * dec_loss   

        # print(dec_loss)
        # print(msg_pred.shape)
        # print(label.shape)

        g_optim.zero_grad()
        dec_loss.backward()
        g_optim.step()

        #精调 MSG 和 D 
        if args.jingtiao:
            requires_grad(generator, False)
            noise = mixing_noise(args.batch, args.latent, args.mixing, device)
            modeuated_noise, msg_gt = old_generate_modulated_noise(args.batch, args.size, device , msg_model=mod, bpp=args.bpp)
            fake_img, _ = generator(noise, emb_secret=True, modeuated_noise=modeuated_noise)
            fake_img = fake_img.detach()
            fake_img = torch.round(255.0 * (fake_img + 1.0) / 2.0)
            fake_img = fake_img / 127.5 - 1.0
            # #decoder gradient
            # # fake_image =  127.5 * (fake_image + 1.0)
            # # noised_image = pipeline(fake_image)
            noised_image = fake_img
            # # noised_image = noised_image / 127.5 - 1.0
            msg_pred = decoder(noised_image) 
            label = msg_gt>=0.5
            dec_loss = binary_cross_entropy_with_logits(msg_pred, label.float())
            # # print(msg_pred)
            jingtiao_dec_acc = (msg_pred >= 0.0).eq(label).sum().float() / msg_gt.numel()
            # dec_loss = args.dec_weight * dec_loss   

            g_optim.zero_grad()
            dec_loss.backward()
            g_optim.step()

        if args.freeze:
            requires_grad(generator, True)


        accumulate(g_ema, g_module, accum)   # g_ema * accum + g_module * (1 - accum)

        if args.withmod:
            accumulate(mod_ema, mod, accum)
        accumulate(decoder_ema, decoder_module, accum)

        loss_reduced = reduce_loss_dict(loss_dict)

        d_loss_val = loss_reduced["d"].mean().item()
        g_loss_val = loss_reduced["g"].mean().item()
        r1_val = loss_reduced["r1"].mean().item()
        path_loss_val = loss_reduced["path"].mean().item()
        real_score_val = loss_reduced["real_score"].mean().item()
        fake_score_val = loss_reduced["fake_score"].mean().item()
        path_length_val = loss_reduced["path_length"].mean().item()

        #计算fid
        if args.fid and get_rank() == 0:
            if i % 2500 == 0:
                sample_mean, sample_cov = calc_mu_sigma_from_stego_samples(g_ema, 18, 20000, None, device, args)
                with open(args.fid_path, "rb") as f:
                    embeds = pickle.load(f)
                    real_mean = embeds["mean"]
                    real_cov = embeds["cov"]
                fid = calc_fid(sample_mean, sample_cov, real_mean, real_cov)
                log_2_file(os.path.join(args.ckpt_path,'result.txt'), f'iter :{str(i)} , fid : {fid}')
                print(f"FID:  {fid}")
        

        if get_rank() == 0:
            pbar.set_description(
                (
                    # f"d: {d_loss_val:.4f}; g: {g_loss_val:.4f}; r1: {r1_val:.4f}; "
                    # f"path: {path_loss_val:.4f}; mean path: {mean_path_length_avg:.4f}; "
                    # f"augment: {ada_aug_p:.4f}"
                    f"dec_acc: {dec_acc:.4f}; "
                    f"valid_dec_acc: {valid_dec_acc:.4f}; "
                    f"sub: {avg_sub:.4f}; "
                    f"change: {avg_change:.4f}; "
                    f"dec weight: {args.dec_weight:.3f}; "
                    # f"fid: {fid}; "
                )
            )

            if wandb and args.wandb:
                wandb.log(
                    {
                        "Generator": g_loss_val,
                        "Discriminator": d_loss_val,
                        "Augment": ada_aug_p,
                        "Rt": r_t_stat,
                        "R1": r1_val,
                        "Path Length Regularization": path_loss_val,
                        "Mean Path Length": mean_path_length,
                        "Real Score": real_score_val,
                        "Fake Score": fake_score_val,
                        "Path Length": path_length_val,
                    }
                )

            if i % 50 == 0:
                with torch.no_grad():
                    g_ema.eval()
                    ori_noise = g_ema.make_noise(batch_size=args.n_sample)
                    if mod_ema is not None:
                        mod_noise = mod_ema(ori_noise[-1])
                        noise_sample, _ = g_ema([sample_z], noise=ori_noise, randomize_noise=False,emb_secret=True, modeuated_noise=mod_noise)
                    else:
                        noise_sample, _ = g_ema([sample_z], randomize_noise=False, noise=ori_noise)
                    noise_sample, _ = g_ema([sample_z], noise=ori_noise)
                    utils.save_image(
                        noise_sample,
                        f"{args.sample_path}/{str(i).zfill(6)}.png",
                        nrow=int(args.n_sample ** 0.5),
                        normalize=True,
                        range=(-1, 1),
                    )
                    
                    
                    mod_finallayer_noise,valid_msg_gt = old_generate_modulated_noise(args.n_sample, args.size, device, ori_noise=ori_noise[-1],
                            msg_model=mod_ema, bpp=args.bpp)
                    
                    valid_latent = torch.randn(args.n_sample, args.latent, device=device)

                    valid_sample, _ = g_ema([valid_latent], noise=ori_noise, emb_secret=True, modeuated_noise=mod_finallayer_noise)
                    sec_sample, _ = g_ema([sample_z], noise=ori_noise, emb_secret=True, modeuated_noise=mod_finallayer_noise)


                    avg_sub, avg_change = getdiff(noise_sample, sec_sample)


                    fake_img = valid_sample
                    fake_img = torch.round(255.0 * (fake_img + 1.0) / 2.0)
                    fake_img = fake_img / 127.5 - 1.0
                    #decoder gradient
                    # fake_image =  127.5 * (fake_image + 1.0)
                    # noised_image = pipeline(fake_image)
                    
                    # noised_image = noised_image / 127.5 - 1.0
                    valid_msg_pred = decoder_ema(fake_img) 
                    label = valid_msg_gt>=0.5
                    # print(msg_pred)
                    # print((valid_msg_pred >= 0.0).eq(label).sum().float())
                    # print(valid_msg_gt.numel())
                    valid_dec_acc = (valid_msg_pred >= 0.0).eq(label).sum().float() / valid_msg_gt.numel()
                    log_2_file(os.path.join(args.ckpt_path,'result.txt'), f'iter :{str(i)} , valid acc : {valid_dec_acc}')
                    # print("valid acc : ")
                    # print(valid_dec_acc)

                    if args.decay and (i%50==0):
                        if args.dec_weight>args.decayto:
                            args.dec_weight *= 0.99


                    # print(torch.sum(sec_sample-noise_sample))
                    utils.save_image(
                        sec_sample,
                        f"{args.sample_path}/{str(i).zfill(6)}_secret.png",
                        nrow=int(args.n_sample ** 0.5),
                        normalize=True,
                        range=(-1, 1),
                    )
            

            


            if i % 2500 == 0:
                if args.withmod:
                    torch.save(
                        {
                            "g": g_module.state_dict(),
                            "d": d_module.state_dict(),
                            "g_ema": g_ema.state_dict(),
                            "g_optim": g_optim.state_dict(),
                            "d_optim": d_optim.state_dict(),
                            "args": args,
                            "ada_aug_p": ada_aug_p,
                            "decoder": decoder_module.state_dict(),
                            "decoder_ema": decoder_ema.state_dict(),
                            "mod": mod.state_dict(),
                            "mod_ema": mod_ema.state_dict()
                        },
                        f"{args.ckpt_path}/{str(i).zfill(6)}.pt",
                    )
                else:
                    torch.save(
                        {
                            "g": g_module.state_dict(),
                            "d": d_module.state_dict(),
                            "g_ema": g_ema.state_dict(),
                            "g_optim": g_optim.state_dict(),
                            "d_optim": d_optim.state_dict(),
                            "args": args,
                            "ada_aug_p": ada_aug_p,
                            "decoder": decoder_module.state_dict(),
                            "decoder_ema": decoder_ema.state_dict(),
                        },
                        f"{args.ckpt_path}/{str(i).zfill(6)}.pt",
                    )
                

def setup_seed(seed=0):
    torch.manual_seed(seed)  # 为CPU设置随机种子
    np.random.seed(seed)  # Numpy module.
    random.seed(seed)  # Python random module.
    if torch.cuda.is_available():
        # torch.backends.cudnn.benchmark = False
        torch.backends.cudnn.deterministic = True
        torch.cuda.manual_seed(seed)  # 为当前GPU设置随机种子
        torch.cuda.manual_seed_all(seed)  # 为所有GPU设置随机种子
        #os.environ['PYTHONHASHSEED'] = str(seed)


if __name__ == "__main__":
    device = "cuda"

    # 创建一个 ArgumentParser 对象,简要设置为该程序要执行什么任务
    parser = argparse.ArgumentParser(description="StyleGAN2 trainer")

    # 调用 add_argument() 方法添加参数
    parser.add_argument("--exp", type=str, help="expriment name", required=True)   # 用于对此次实验进行命名，必须指定
    parser.add_argument("path", type=str, help="path to the lmdb dataset")         # 训练数据集路径，必须指定
    parser.add_argument('--arch', type=str, default='stylegan2', help='model architectures (stylegan2 | swagan)')
    parser.add_argument(
        "--iter", type=int, default=1200000, help="total training iterations"
    )
    parser.add_argument(
        "--batch", type=int, default=16, help="batch sizes for each gpus"
    )
    parser.add_argument(
        "--size", type=int, default=256, help="image sizes for the model"
    )
    parser.add_argument(
        "--ckpt",  # 加载先前的断点
        type=str,
        default=None,
        help="path to the checkpoints to resume training",
    )
    parser.add_argument(
        "--ckpt_path",  # 当前模型训练保存断点的路径
        type=str,
        default=None,
        help="ckpt store path",
    )
    parser.add_argument(
        "--sample_path",  # 抽样的样本保存的路径
        type=str,
        default=None,
        help="sample store path",
    )
    parser.add_argument(
        "--n_sample",
        type=int,
        default=64,
        help="number of the samples generated during training",
    )
    parser.add_argument(
        "--fid_path",
        type=str,
        default="inception_celeb_128.pkl",  # 原始数据集的特征pkl文件路径
        help="fid pickle path",
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=1,
        help="random seed",
    )
    parser.add_argument(
        "--bpp",
        type=int,
        default=1,
        help="bit per pixel",
    )
    parser.add_argument(
        "--emb_step",
        type=int,
        default=None,
        help="7:128 8:256",
    )
    parser.add_argument(
        "--finetune_fromori",
        # type=bool,
        # default=True,
        action="store_true",
        help="whether the model is finetuned from an original stylegan2",
    )
    parser.add_argument(
        "--withmod",  # 弃用
        # type=bool,
        # default=True,
        action="store_true",
        help="msg ",
    )
    parser.add_argument(
        "--freeze",
        # type=bool,
        # default=True,
        action="store_true",
        help="freeze lower block of generator when train decoder ",
    )
    parser.add_argument(
        "--jingtiao",
        # type=bool,
        # default=True,
        action="store_true",
        help="msg ",
    )
    parser.add_argument(
        "--ganwithnoise",
        # type=bool,
        # default=True,
        action="store_true",
        help=" ",
    )
    parser.add_argument(
        "--fid",
        # type=bool,
        # default=True,
        action="store_false",
        help=" ",
    )
    parser.add_argument(
        "--decay",
        # type=bool,
        # default=True,
        action="store_true",
        help="dec weight decay ",
    )
    parser.add_argument(
        "--dec_weight",
        type=float,
        default=0.2,
        help="decode loss weight",
    )
    parser.add_argument(
        "--decayto",
        type=float,
        default=0.04,
        help="decayto",
    )

    # *************************************************************************************
    parser.add_argument(
        "--r1", type=float, default=10, help="weight of the r1 regularization"
    )
    parser.add_argument(
        "--path_regularize",
        type=float,
        default=2,
        help="weight of the path length regularization",
    )
    parser.add_argument(
        "--path_batch_shrink",
        type=int,
        default=2,
        help="batch size reducing factor for the path length regularization (reduce memory consumption)",
    )
    parser.add_argument(
        "--d_reg_every",
        type=int,
        default=16,
        help="interval of the applying r1 regularization",
    )
    parser.add_argument(
        "--g_reg_every",
        type=int,
        default=4,
        help="interval of the applying path length regularization",
    )
    parser.add_argument(
        "--mixing", type=float, default=0.9, help="probability of latent code mixing"
    )

    parser.add_argument("--lr", type=float, default=0.002, help="learning rate")
    parser.add_argument(
        "--channel_multiplier",
        type=int,
        default=2,
        help="channel multiplier factor for the model. config-f = 2, else = 1",
    )
    parser.add_argument(
        "--wandb", action="store_true", help="use weights and biases logging"
    )
    parser.add_argument(
        "--local_rank", type=int, default=0, help="local rank for distributed training"
    )
    parser.add_argument(
        "--augment", action="store_true", help="apply non leaking augmentation"
    )
    parser.add_argument(
        "--augment_p",
        type=float,
        default=0,
        help="probability of applying augmentation. 0 = use adaptive augmentation",
    )
    parser.add_argument(
        "--ada_target",
        type=float,
        default=0.6,
        help="target augmentation probability for adaptive augmentation",
    )
    parser.add_argument(
        "--ada_length",
        type=int,
        default=500 * 1000,
        help="target duraing to reach augmentation probability for adaptive augmentation",
    )
    parser.add_argument(
        "--ada_every",
        type=int,
        default=256,
        help="probability update interval of the adaptive augmentation",
    )
    parser.add_argument(
        "--dec_lrmul",
        type=float,
        default=1,
        help="decode loss weight",
    )
    # *************************************************************************************

    warnings.filterwarnings("ignore",category=DeprecationWarning)

    # 使用 parse_args() 解析添加的参数
    args = parser.parse_args()

    setup_seed(args.seed)

    args.exp += "_bpp" +str(args.bpp) + "_dec" +str(args.dec_weight) \
        + "_batch" +str(args.batch) + "_seed" +str(args.seed)
    
    if args.jingtiao:
        args.exp += "_jt"
    if args.decay:
        args.exp += "_decayto" + str(args.decayto)
    if args.withmod:
        args.exp += "_withmod"

    args.ckpt_path = "checkpoint_" + args.exp + "_" +str(args.size)
    args.sample_path = "sample_" + args.exp + "_" +str(args.size)


    if not os.path.exists(args.ckpt_path):
        os.mkdir(args.ckpt_path)
    if not os.path.exists(args.sample_path):
        os.mkdir(args.sample_path)

    n_gpu = int(os.environ["WORLD_SIZE"]) if "WORLD_SIZE" in os.environ else 1
    args.distributed = n_gpu > 1

    if args.distributed:
        torch.cuda.set_device(args.local_rank)
        torch.distributed.init_process_group(backend="nccl", init_method="env://")
        synchronize()

    args.latent = 512
    args.n_mlp = 8

    args.start_iter = 0

    args.log_size = int(math.log(args.size, 2))
    args.emb_step = args.log_size
    
    from model_lastone_bppn import Generator, Discriminator

    argsDict = args.__dict__    # 将args 转换为dict
    with open(os.path.join(args.ckpt_path,'setting.txt'), 'w') as f:
        f.writelines('------------------ start ------------------' + '\n')
        for eachArg, value in argsDict.items():
            f.writelines(eachArg + ' : ' + str(value) + '\n')
        f.writelines('------------------- end -------------------')

    generator = Generator(
        args.size, args.latent, args.n_mlp, channel_multiplier=args.channel_multiplier, bpp=args.bpp
    ).to(device)
    discriminator = Discriminator(
        args.size, channel_multiplier=args.channel_multiplier
    ).to(device)
    g_ema = Generator(
        args.size, args.latent, args.n_mlp, channel_multiplier=args.channel_multiplier, bpp=args.bpp
    ).to(device)

    g_ema.eval()
    accumulate(g_ema, generator, 0)

    decoder = Decoder(emb_step=args.emb_step, log_size=args.log_size,data_depth=args.bpp).to(device)  #128 : 5
    decoder_ema = Decoder(emb_step=args.emb_step, log_size=args.log_size,data_depth=args.bpp).to(device)  #128 : 5
    decoder_ema.eval()
    accumulate(decoder_ema, decoder, 0)

    if args.withmod:
        mod = MsgModulator(data_depth=args.bpp).to(device)  # 编码模块  弃用
        mod_ema = MsgModulator(data_depth=args.bpp).to(device)  
        mod_ema.eval()
        accumulate(mod_ema, mod, 0)
    else:
        mod = None
        mod_ema = None

    g_reg_ratio = args.g_reg_every / (args.g_reg_every + 1)
    d_reg_ratio = args.d_reg_every / (args.d_reg_every + 1)

    g_optim = optim.Adam(
        generator.parameters(),
        lr=args.lr * g_reg_ratio,
        betas=(0 ** g_reg_ratio, 0.99 ** g_reg_ratio),
    )
    
    d_optim = optim.Adam(
        discriminator.parameters(),
        lr=args.lr * d_reg_ratio,
        betas=(0 ** d_reg_ratio, 0.99 ** d_reg_ratio),
    )

    # ste_optim = optim.Adam([
    #     {'params': decoder.parameters()},
    #     {'params': msg_modulator.parameters()},
    #     ],
    #     lr=args.lr,
    # )

    if not args.finetune_fromori:
        g_optim.add_param_group({'params': decoder.parameters(),
                     'lr': args.lr * args.dec_lrmul,
                     # 'mult': 0.1,
                    })
        if args.withmod:
            g_optim.add_param_group({'params': mod.parameters(),
                'lr': args.lr * args.dec_lrmul,
                # 'mult': 0.1,
                 })
    

    if args.ckpt is not None:
        print("load model:", args.ckpt)

        # Load all tensors onto the CPU, using a function
        ckpt = torch.load(args.ckpt, map_location=lambda storage, loc: storage)

        try:
            ckpt_name = os.path.basename(args.ckpt)
            args.start_iter = int(os.path.splitext(ckpt_name)[0])

        except ValueError:
            pass

        generator.load_state_dict(ckpt["g"])
        discriminator.load_state_dict(ckpt["d"])
        g_ema.load_state_dict(ckpt["g_ema"])

        g_optim.load_state_dict(ckpt["g_optim"])
        d_optim.load_state_dict(ckpt["d_optim"])

        if not args.finetune_fromori:
            if "decoder" in ckpt:
                decoder.load_state_dict(ckpt["decoder"])

            if "decoder_ema" in ckpt:
                decoder_ema.load_state_dict(ckpt["decoder_ema"])
            elif "decoder" in ckpt:
                decoder_ema.load_state_dict(ckpt["decoder"])

            if args.withmod:
                if "mod" in ckpt:
                    mod.load_state_dict(ckpt["mod"])
                
                if "mod_ema" in ckpt:
                    mod_ema.load_state_dict(ckpt["mod_ema"])
                elif "mod" in ckpt:
                    mod_ema.load_state_dict(ckpt["mod"])
            

    if args.finetune_fromori:
        g_optim.add_param_group({'params': decoder.parameters(),
                     'lr': args.lr * args.dec_lrmul,
                     # 'mult': 0.1,
                    })
        if args.withmod:
            g_optim.add_param_group({'params': mod.parameters(),
                'lr': args.lr * args.dec_lrmul,
                # 'mult': 0.1,
                 })

    if args.distributed:
        generator = nn.parallel.DistributedDataParallel(
            generator,
            device_ids=[args.local_rank],
            output_device=args.local_rank,
            broadcast_buffers=False,
        )

        discriminator = nn.parallel.DistributedDataParallel(
            discriminator,
            device_ids=[args.local_rank],
            output_device=args.local_rank,
            broadcast_buffers=False,
        )

        decoder = nn.parallel.DistributedDataParallel(
            decoder,
            device_ids=[args.local_rank],
            output_device=args.local_rank,
            broadcast_buffers=False,
        )

    transform = transforms.Compose(
        [
            transforms.RandomHorizontalFlip(),
            transforms.ToTensor(),
            transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5), inplace=True),
        ]
    )

    dataset = MultiResolutionDataset(args.path, transform, args.size)
    loader = data.DataLoader(
        dataset,    # 传入的数据集
        batch_size=args.batch,
        sampler=data_sampler(dataset, shuffle=True, distributed=args.distributed),
        drop_last=True,
    )

    if get_rank() == 0 and wandb is not None and args.wandb:
        wandb.init(project="stylegan 2")

    pipeline = Noiser(noise_layers=[Identity()], device='cuda', prob=1)

    train(args, loader, generator, discriminator, decoder, mod, g_optim, 
        d_optim, None, g_ema, decoder_ema, mod_ema, device)
