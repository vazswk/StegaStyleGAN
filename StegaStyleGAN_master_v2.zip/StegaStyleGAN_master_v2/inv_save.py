import argparse
import math
import os
os.environ['CUDA_VISIBLE_DEVICES'] = '1'
import torch
from torch import optim
from torch.nn import functional as F
from torchvision import transforms
from PIL import Image
from tqdm import tqdm

import lpips

from old_ste_model import Decoder
from utils import *

from glob import glob


def noise_regularize(noises):
    loss = 0

    for noise in noises:
        size = noise.shape[2]

        while True:
            loss = (
                loss
                + (noise * torch.roll(noise, shifts=1, dims=3)).mean().pow(2)
                + (noise * torch.roll(noise, shifts=1, dims=2)).mean().pow(2)
            )

            if size <= 8:
                break

            noise = noise.reshape([-1, 1, size // 2, 2, size // 2, 2])
            noise = noise.mean([3, 5])
            size //= 2

    return loss


def noise_normalize_(noises):
    for noise in noises:
        mean = noise.mean()
        std = noise.std()

        noise.data.add_(-mean).div_(std)


def get_lr(t, initial_lr, rampdown=0.25, rampup=0.05):
    lr_ramp = min(1, (1 - t) / rampdown)
    lr_ramp = 0.5 - 0.5 * math.cos(lr_ramp * math.pi)
    lr_ramp = lr_ramp * min(1, t / rampup)

    return initial_lr * lr_ramp


def latent_noise(latent, strength):
    noise = torch.randn_like(latent) * strength

    return latent + noise


def make_image(tensor):
    return (
        tensor.detach()
        .clamp_(min=-1, max=1)
        .add(1)
        .div_(2)
        .mul(255)
        .type(torch.uint8)
        .permute(0, 2, 3, 1)
        .to("cpu")
        .numpy()
    )


def getmsggt(noises, emb_idx):
    x = noises[emb_idx].detach().clone()
    x[x>0] = 1
    x[x<0] = 0
    return x


if __name__ == "__main__":
    device = "cuda"

    parser = argparse.ArgumentParser(
        description="Image projector to the generator latent spaces"
    )
    parser.add_argument(
        "--ckpt", type=str, default=r"attack_bppn_model/checkpoint_celeba_jpeg75asl_msgrepeat1_emb5_dec0.7_bpp1_batch16_seed75_size128_jt_decayto0.7_wanway/370000.pt"
    )
    parser.add_argument(
        "--size", type=int, default=128, help="output image sizes of the generator"
    )
    parser.add_argument(
        "--emb_step", type=int, default=7, help="  "
    )
    parser.add_argument(
        "--lr_rampup",
        type=float,
        default=0.05,
        help="duration of the learning rate warmup",
    )
    parser.add_argument(
        "--lr_rampdown",
        type=float,
        default=0.25,
        help="duration of the learning rate decay",
    )
    parser.add_argument("--lr", type=float, default=0.1, help="learning rate")
    parser.add_argument(
        "--noise", type=float, default=0.05, help="strength of the noise level"
    )
    parser.add_argument(
        "--noise_ramp",
        type=float,
        default=0.75,
        help="duration of the noise level decay",
    )
    parser.add_argument("--step", type=int, default=15005, help="optimize iterations")
    parser.add_argument(
        "--noise_regularize",
        type=float,
        default=1e5,
        help="weight of the noise regularization",
    )
    parser.add_argument("--mse", type=float, default=5, help="weight of the mse loss")
    parser.add_argument(
        "--w_plus",
        action="store_true",
        help="allow to use distinct latent codes to each layers",
    )
    parser.add_argument(
        "--files", type=str, default="inv", help="path to image files to be projected"
    )

    parser.add_argument(
        "--bpp", type=int, default=1, help=" bpp "
    )
    parser.add_argument(
        "--attack",
        # type=bool,
        # default=True,
        action = "store_true",
        help="",
    )
    args = parser.parse_args()
    
    args.wanway = True
    args.msg_repeat = 1
    args.lasttwo = False
    
    if args.attack:
        from model_attack_bppn import Generator
    else:
        from model_lastone_bppn import Generator
    args.log_size = int(math.log(args.size, 2))
    

    n_mean_latent = 10000

    resize = min(args.size, 256)

    transform = transforms.Compose(
        [
            transforms.Resize(resize),
            transforms.CenterCrop(resize),
            transforms.ToTensor(),
            transforms.Normalize([0.5, 0.5, 0.5], [0.5, 0.5, 0.5]),
        ]
    )

    


    ckpt = torch.load(args.ckpt)

    if args.attack:
        g_ema = Generator(
            args.size, 512, 8, emb_step=args.emb_step, bpp=args.bpp
        )
    else:
        g_ema = Generator(args.size, 512, 8, bpp=args.bpp)
        
    g_ema.load_state_dict(ckpt["g_ema"], strict=False)
    g_ema.eval()
    g_ema = g_ema.to(device)

    decoder = Decoder(emb_step=args.emb_step, data_depth=args.bpp, log_size=args.log_size, msg_repeat=1, wanway=True).to(device)  #128 : 7
    decoder.load_state_dict(ckpt["decoder_ema"])




    imgs = []

    files = glob(os.path.join(args.files, "*"))
    print(files)
    n_target = len(files)
    for imgfile in files:
        img = transform(Image.open(imgfile).convert("RGB"))
        base_name = imgfile.split("/")[-1].split(".")[0]+imgfile.split("/")[-1].split(".")[1]
        imgs = [img]
        # imgs.append(img)

        imgs = torch.stack(imgs, 0).to(device)






        with torch.no_grad():
            noise_sample = torch.randn(n_mean_latent, 512, device=device)
            latent_out = g_ema.style(noise_sample)

            latent_mean = latent_out.mean(0)
            latent_std = ((latent_out - latent_mean).pow(2).sum() / n_mean_latent) ** 0.5

        percept = lpips.PerceptualLoss(
            model="net-lin", net="vgg", use_gpu=device.startswith("cuda")
        )

        # noises_single = g_ema.make_noise(imgs.shape[0])
        # noises = []
        # for noise in noises_single:
        #     noises.append(noise.repeat(imgs.shape[0], 1, 1, 1).normal_())
        noises = g_ema.make_noise(imgs.shape[0])
        # print(noises[-1].shape)
        if args.bpp>1:
            print(noises)

        latent_in = latent_mean.detach().clone().unsqueeze(0).repeat(imgs.shape[0], 1)

        if args.w_plus:
            latent_in = latent_in.unsqueeze(1).repeat(1, g_ema.n_latent, 1)

        latent_in.requires_grad = True

        for noise in noises:
            noise.requires_grad = True

        optimizer = optim.Adam([latent_in] + noises, lr=args.lr)

        pbar = tqdm(range(args.step))
        latent_path = []

        for i in pbar:
            t = i / args.step
            lr = get_lr(t, args.lr)
            optimizer.param_groups[0]["lr"] = lr
            noise_strength = latent_std * args.noise * max(0, 1 - t / args.noise_ramp) ** 2
            latent_n = latent_noise(latent_in, noise_strength.item())

            img_gen, _ = g_ema([latent_n], input_is_latent=True, noise=noises)

            batch, channel, height, width = img_gen.shape

            if height > 256:
                factor = height // 256

                img_gen = img_gen.reshape(
                    batch, channel, height // factor, factor, width // factor, factor
                )
                img_gen = img_gen.mean([3, 5])

            p_loss = percept(img_gen, imgs).sum()
            n_loss = noise_regularize(noises)
            mse_loss = F.mse_loss(img_gen, imgs)

            loss = p_loss + args.noise_regularize * n_loss + args.mse * mse_loss

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            noise_normalize_(noises)

            # if (i + 1) % 100 == 0:
            #     latent_path.append(latent_in.detach().clone())

            # print(noises[-1].shape)
            # final_noise = noises[-1].detach().clone()
            # t_noise, msg_gt = old_generate_modulated_noise(1, 128, device, msg_model = None, ori_noise = final_noise, bpp=args.bpp)
            # img_gen, _ = g_ema([latent_in.detach()], input_is_latent=True, noise=noises, emb_secret = True, modeuated_noise = t_noise)

            img_gen, _ = g_ema([latent_in.detach()], input_is_latent=True, noise=noises, )
            msg_gt = getmsggt(noises, g_ema.emb_idx)
            

            fake_img = img_gen.detach().clone()
            fake_img = torch.round(255.0 * (fake_img + 1.0) / 2.0)
            fake_img = fake_img / 127.5 - 1.0

            msg_pred = decoder(fake_img) 
            label = msg_gt>=0.5

            assert msg_gt.shape==msg_pred.shape
            # dec_loss = binary_cross_entropy_with_logits(msg_pred, label.float())
            # # print(msg_pred)
            dec_acc = (msg_pred >= 0.0).eq(label).sum().float() / msg_gt.numel()


            if i%2500==0:
                img_ar = make_image(img_gen)
                if args.w_plus:
                    outdir = args.files+"outimg_zsave_plus"
                else:
                    outdir = args.files+"outimg_zsave"
                if not os.path.exists(outdir):
                    os.mkdir(outdir)
                for idx in range(1):

                    img_name = os.path.join(outdir,base_name + f"_iter{i}_{round(float(dec_acc),4)}_lpips{round(float(p_loss),4)}_" +str(round(float(mse_loss),4))+".png")
                    pil_img = Image.fromarray(img_ar[idx])
                    pil_img.save(img_name)
            
            if i>=3500 and i%500==0:
                if args.w_plus:
                    outdir = args.files+"out_zsave_plus"
                else:
                    outdir = args.files+"out_zsave"
                
                if not os.path.exists(outdir):
                    os.mkdir(outdir)
                
                z_name = os.path.join(outdir, f"{base_name}_iter{i}_lpips{round(float(p_loss),4)}_{round(float(dec_acc),4)}.pt")
                torch.save({
                    "latent": latent_in[0],
                    "noise": noises,
                }, z_name)

            pbar.set_description(
                (
                    f"perceptual: {p_loss.item():.4f}; noise regularize: {n_loss.item():.4f};"
                    f" mse: {mse_loss.item():.4f}; lr: {lr:.4f};"
                    f"acc: {dec_acc:.4f}"
                )
            )

        # img_gen, _ = g_ema([latent_path[-1]], input_is_latent=True, noise=noises)

        filename = os.path.splitext(os.path.basename(args.files[0]))[0] + ".pt"

        # img_ar = make_image(img_gen)

        # result_file = {}
        # for i, input_name in enumerate(files):
        #     noise_single = []
        #     for noise in noises:
        #         noise_single.append(noise[i : i + 1])

        #     result_file[input_name] = {
        #         "img": img_gen[i],
        #         "latent": latent_in[i],
        #         "noise": noise_single,
        #     }

        #     img_name = os.path.splitext(os.path.basename(input_name))[0] + "-project.png"
        #     pil_img = Image.fromarray(img_ar[i])
        #     pil_img.save(img_name)

        # torch.save(result_file, filename)
