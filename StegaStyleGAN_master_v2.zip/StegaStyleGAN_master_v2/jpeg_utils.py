# -*- coding: utf-8 -*-

import zlib
import math
from math import exp
import numpy as np
import torch
# from reedsolo import RSCodec
from torch.nn.functional import conv2d
import itertools
import scipy.io as io
from torch import nn
from torch.autograd import Function
import torch.nn.functional as F


t_table = np.array(
    [[16, 11, 10, 16, 24, 40, 51, 61], [12, 12, 14, 19, 26, 58, 60, 55],
	 [14, 13, 16, 24, 40, 57, 69, 56], [14, 17, 22, 29, 51, 87, 80, 62],
	 [18, 22, 37, 56, 68, 109, 103, 77], [24, 35, 55, 64, 81, 104, 113, 92],
     [49, 64, 78, 87, 103, 121, 120, 101], [72, 92, 95, 98, 112, 100, 103, 99]],dtype=np.float32)

alpha = np.array([1. / np.sqrt(2)] + [1] * 7, dtype=np.float32)
alpha = np.outer(alpha, alpha)

cos_tensor_idct = np.zeros((8, 8, 8, 8), dtype=np.float32)
for u, v, i, j in itertools.product(range(8), repeat=4):
    cos_tensor_idct[u, v, i, j] = np.cos((2 * i + 1) * u * np.pi / 16) * np.cos(
        (2 * j + 1) * v * np.pi / 16)

cos_tensor_dct = np.zeros((8, 8, 8, 8), dtype=np.float32)
for i, j, u, v in itertools.product(range(8), repeat=4):
    cos_tensor_dct[i, j, u, v] = np.cos((2 * i + 1) * u * np.pi / 16) * np.cos((2 * j + 1) * v * np.pi / 16)

def text_to_bits(text):
    """Convert text to a list of ints in {0, 1}"""
    return bytearray_to_bits(text_to_bytearray(text))


def bits_to_text(bits):
    """Convert a list of ints in {0, 1} to text"""
    return bytearray_to_text(bits_to_bytearray(bits))


def bytearray_to_bits(x):
    """Convert bytearray to a list of bits"""
    result = []
    for i in x:
        bits = bin(i)[2:]
        bits = '00000000'[len(bits):] + bits
        result.extend([int(b) for b in bits])

    return result


def bits_to_bytearray(bits):
    """Convert a list of bits to a bytearray"""
    ints = []
    for b in range(len(bits) // 8):
        byte = bits[b * 8:(b + 1) * 8]
        ints.append(int(''.join([str(bit) for bit in byte]), 2))

    return bytearray(ints)


def text_to_bytearray(text):
    """Compress and add error correction"""
    assert isinstance(text, str), "expected a string"
    x = zlib.compress(text.encode("utf-8"))
    x = rs.encode(bytearray(x))

    return x


def bytearray_to_text(x):
    """Apply error correction and decompress"""
    try:
        text = rs.decode(x)
        text = zlib.decompress(text)
        return text.decode("utf-8")
    except BaseException:
        return False


def first_element(storage, loc):
    """Returns the first element of two"""
    return storage


def gaussian(window_size, sigma):
    """Gaussian window.

    https://en.wikipedia.org/wiki/Window_function#Gaussian_window
    """
    _exp = [exp(-(x - window_size // 2) ** 2 / float(2 * sigma ** 2)) for x in range(window_size)]
    gauss = torch.Tensor(_exp)
    return gauss / gauss.sum()


def create_window(window_size, channel):
    _1D_window = gaussian(window_size, 1.5).unsqueeze(1)
    _2D_window = _1D_window.mm(_1D_window.t()).float().unsqueeze(0).unsqueeze(0)
    window = _2D_window.expand(channel, 1, window_size, window_size).contiguous()
    return window


def _ssim(img1, img2, window, window_size, channel, size_average=True):

    padding_size = window_size // 2

    mu1 = conv2d(img1, window, padding=padding_size, groups=channel)
    mu2 = conv2d(img2, window, padding=padding_size, groups=channel)

    mu1_sq = mu1.pow(2)
    mu2_sq = mu2.pow(2)
    mu1_mu2 = mu1 * mu2

    sigma1_sq = conv2d(img1 * img1, window, padding=padding_size, groups=channel) - mu1_sq
    sigma2_sq = conv2d(img2 * img2, window, padding=padding_size, groups=channel) - mu2_sq
    sigma12 = conv2d(img1 * img2, window, padding=padding_size, groups=channel) - mu1_mu2

    C1 = 0.01**2
    C2 = 0.03**2

    _ssim_quotient = ((2 * mu1_mu2 + C1) * (2 * sigma12 + C2))
    _ssim_divident = ((mu1_sq + mu2_sq + C1) * (sigma1_sq + sigma2_sq + C2))

    ssim_map = _ssim_quotient / _ssim_divident

    if size_average:
        return ssim_map.mean()
    else:
        return ssim_map.mean(1).mean(1).mean(1)


def ssim(img1, img2, window_size=11, size_average=True):
    (_, channel, _, _) = img1.size()
    window = create_window(window_size, channel)

    if img1.is_cuda:
        window = window.cuda(img1.get_device())
    window = window.type_as(img1)

    return _ssim(img1, img2, window, window_size, channel, size_average)


y_table = np.array(
    [[16, 11, 10, 16, 24, 40, 51, 61], [12, 12, 14, 19, 26, 58, 60, 55],
     [14, 13, 16, 24, 40, 57, 69, 56], [14, 17, 22, 29, 51, 87, 80, 62],
     [18, 22, 37, 56, 68, 109, 103, 77], [24, 35, 55, 64, 81, 104, 113, 92],
     [49, 64, 78, 87, 103, 121, 120, 101], [72, 92, 95, 98, 112, 100, 103, 99]], dtype=np.float32)

c_table = np.empty((8, 8), dtype=np.float32)
c_table.fill(99)
c_table[:4, :4] = np.array([[17, 18, 24, 47],
                            [18, 21, 26, 66],
                            [24, 26, 56, 99],
                            [47, 66, 99, 99]])

def quality_to_factor(quality, device, T_table):
    t_table = torch.from_numpy(T_table)
    if (quality <= 0):
        quality = 1
    if (quality > 100):
        quality = 100
    if quality < 50:
        quality = 5000. / quality
    else:
        quality = 200. - quality * 2
        table = (t_table.cuda(device) * quality + 50.) / 100.

    table = torch.floor(table)
    x = torch.ones(table.size()).cuda(table.get_device())
    torch.where(table < 1, x, table)
    return table

def jpeg_quantize(patches, quality, T_table):
    # quality = torch.from_numpy(quality)
    table = quality_to_factor(quality, patches.get_device(), T_table)
    # y_table = torch.from_numpy(y_table)
    table = table.floor()
    table = table.unsqueeze(0).unsqueeze(1)
    table = table.expand(patches.size())
    return patches / table

# y_table = quality_to_factor(quality)
def jpeg_dequantize(patches, quality, T_table):
    # quality = torch.from_numpy(quality)
    y_table = quality_to_factor(quality, patches.get_device(), T_table)
    # y_table = torch.from_numpy(y_table)
    y_table = y_table.floor()
    y_table = y_table.unsqueeze(0).unsqueeze(1)
    y_table = y_table.expand(patches.size())
    return patches * y_table


def image_to_patches(input):
    # input: batch x 1 x h x w
    # output: batch x h*w/64 x h x w
    k = 8
    input = torch.squeeze(input, dim=1)  # 删除第1维度
    batch_size, H, W = input.size()
    input_reshaped = input.view(batch_size, H // k, k, W // k, k)
    patches = input_reshaped.permute(0, 1, 3, 2, 4)
    return patches.reshape(batch_size, -1, k, k)


def patches_to_image(patches, height, width):
    # input: batch x h*w/64 x h x w
    # output: batch x h x w
    k = 8
    batch_size = patches.size(0)
    image_reshaped = patches.view(batch_size, height // k, width // k, k, k)
    image_reshaped = image_reshaped.permute(0, 1, 3, 2, 4)
    output = image_reshaped.reshape(batch_size, 1, height, width)
    return output

def dct_8x8(input):
    Alpha = torch.from_numpy(alpha)
    image = input
    tensor = torch.from_numpy(cos_tensor_dct)
    result = torch.einsum("ijkl,klmn->ijmn", (image, tensor.cuda(input.get_device())))
    result = 0.25 * result * Alpha.cuda(input.get_device())
    return result

def idct_8x8(input):
    Alpha = torch.from_numpy(alpha)
    image = 0.25 * input * Alpha.cuda(input.get_device())
    tensor = torch.from_numpy(cos_tensor_idct)
    result = torch.einsum("ijkl,klmn->ijmn", (image, tensor.cuda(input.get_device())))
    return result + 128.0

def jpeg_decompress(dct, quality, T_table):
    N, C, H, W = dct.size()
    Dct_patches = image_to_patches(dct)
    dct_dequantize_patches = jpeg_dequantize(Dct_patches, quality, T_table)
    decomp_patches = idct_8x8(dct_dequantize_patches)
    decomp = patches_to_image(decomp_patches, H, W)
    # cover_dct1 = decomp[0]
    # cover_dct1 = torch.squeeze(cover_dct1, dim=0)  # 删除第1维度
    # io.savemat('de_cover.mat', {'de_cover': cover_dct1.detach().cpu().numpy().astype('float16')})
    return decomp

def jpeg_compress(image_spatial, quality, T_table):
    image_spatial = image_spatial - 128.0
    N, C, H, W = image_spatial.size()
    spatial_patches = image_to_patches(image_spatial)
    dct_patches = dct_8x8(spatial_patches)
    dct_patches = jpeg_quantize(dct_patches, quality, T_table)
    dct_coef = patches_to_image(dct_patches, H, W)
    return dct_coef



def rgb2yuv(image_rgb, image_yuv_out):
    """ Transform the image from rgb to yuv """
    image_yuv_out[:, 0, :, :] = 0.299 * image_rgb[:, 0, :, :].clone() + 0.587 * image_rgb[:, 1, :, :].clone() + 0.114 * image_rgb[:, 2, :, :].clone()
    image_yuv_out[:, 1, :, :] = -0.168736 * image_rgb[:, 0, :, :].clone() + -0.331264 * image_rgb[:, 1, :, :].clone() + 0.5 * image_rgb[:, 2, :, :].clone() + 128.
    image_yuv_out[:, 2, :, :] = 0.5 * image_rgb[:, 0, :, :].clone() + -0.418688 * image_rgb[:, 1, :, :].clone() + -0.081312 * image_rgb[:, 2, :, :].clone() + 128.


def yuv2rgb(image_yuv, image_rgb_out):
    """ Transform the image from yuv to rgb """
    image_rgb_out[:, 0, :, :] = image_yuv[:, 0, :, :].clone() + 1.1402 * (image_yuv[:, 2, :, :].clone()-128.)
    image_rgb_out[:, 1, :, :] = image_yuv[:, 0, :, :].clone() + -0.344136 * (image_yuv[:, 1, :, :].clone()-128.) + -0.714136 * (image_yuv[:, 2, :, :].clone()-128.)
    image_rgb_out[:, 2, :, :] = image_yuv[:, 0, :, :].clone() + 1.772 * (image_yuv[:, 1, :, :].clone()-128.)



def downsampling_420(image):
    y, cb, cr = torch.split(image, 1, dim=1)
    cb = F.avg_pool2d(cb, 2)
    cr = F.avg_pool2d(cr, 2)
    return (y, cb, cr)

def upsampling_420(y, cb, cr):
    def repeat(x, n=2):
        h, w = x.shape[2:4]
        x = x.unsqueeze(-1).repeat(1, 1, 1, n, n).view(-1, 1, h*n, w*n)
        return x

    cb = repeat(cb)
    cr = repeat(cr)
    return torch.cat((y, cb, cr), dim=1)





class SUJPEG(nn.Module):
    def __init__(self, height=128, width=128, quality=75):
        ''' Initialize the DiffJPEG layer
        Inputs:
            height(int): Original image height
            width(int): Original image width
            differentiable(bool): If true uses custom differentiable
                rounding function, if false uses standrard torch.round
            quality(float): Quality factor for jpeg compression scheme. 
        '''
        super(SUJPEG, self).__init__()
        
        self.quality = quality

        # self.compress = compress_jpeg(rounding=rounding, factor=factor)
        # self.decompress = decompress_jpeg(height, width, rounding=rounding,
        #                                   factor=factor)

    def forward(self, x):
        '''
        '''
        x = torch.clamp(x,-1,1)
        image_rgb = torch.round(255.0 * (x + 1.0) / 2.0)

        image_yuv = torch.empty_like(image_rgb)
        rgb2yuv(image_rgb, image_yuv)
        y, cb, cr = downsampling_420(image_yuv)

        dct_y = jpeg_compress(y,self.quality, y_table)
        dct_cb = jpeg_compress(cb,self.quality, c_table)
        dct_cr = jpeg_compress(cr,self.quality, c_table)

        y_out = jpeg_decompress(dct_y, self.quality, y_table)
        cb_out = jpeg_decompress(dct_cb, self.quality, c_table)
        cr_out = jpeg_decompress(dct_cr, self.quality, c_table)


        image_yuv_out = upsampling_420(y_out, cb_out, cr_out)
        

        # transform from yuv to to rgb
        image_rgb_out = torch.empty_like(image_yuv_out)
        yuv2rgb(image_yuv_out, image_rgb_out)
        

        #截断到0到255

        image_rgb_out = torch.clamp(image_rgb_out,0,255)

        # print(torch.max())

                    
                    
        # x_clone = x.clone()
        # x_detach = x_clone.detach()

        out = image_rgb_out / 127.5 - 1.0

        # gap = recovered - x_detach

        # out = x+gap
        # print("sum of residual")
        # print(torch.sum(gap))


        return out





###############################################################################################################################################################
###############################################################################################################################################################
###############################################################################################################################################################
###############################################################################################################################################################
###############################################################################################################################################################
###############################################################################################################################################################
##################################################################################################################################################################




    
def jpeg_mode_cal(image_spatial):
    image_spatial = image_spatial - 128.0
    N, C, H, W = image_spatial.size()
    spatial_patches = image_to_patches(image_spatial)
    dct_patches = dct_8x8(spatial_patches)
    dct_coef = patches_to_image(dct_patches, H, W)
    for i, j in itertools.product(range(8), repeat=2):  # 先遍历j，后遍历i
        x_tmp = dct_coef[:, :, i::8, j::8]
        x = torch.cat((x, x_tmp), dim=1) if i+j else x_tmp
        y = x[:, 1:64, :, :]
    y = torch.abs(y)
    return y
    

## steganography ##

def mode_2D(input):
    output = torch.zeros(8, 8).cuda(input.get_device())
    for i in range(1, 64):
        x = i // 8
        y = i % 8
        output[x, y] = input[i-1]
    return output


def num_nzac_count(dct):
    N, C, H, W = dct.size()
    Dc_num = C * H * W / 64
    num_nz_tmp = torch.nonzero(dct)
    Temp = num_nz_tmp[:, 0]
    num_nz = torch.zeros(N)
    for i in range(N):
        num_nz[i] = int((Temp == i).sum())
    num_nzac = num_nz - Dc_num
    return num_nzac

# JPEG_mode
def JPEG_mode(mode_table, size, perc, device):
    mode_table = torch.from_numpy(mode_table)
    mode_table = mode_table.cuda(device)
    mode_table = 1. / (mode_table * perc)
    mode_table = mode_table.repeat(int(size[2]/8), int(size[3]/8))
    mode = mode_table.unsqueeze(0).unsqueeze(1)
    mode = mode.expand(size)
    return mode

# 空域图像，JPEG压缩后的DCT系数（无量化），按模式抽取
def jpeg_mode_cal(image_spatial):
    image_spatial = image_spatial - 128.0
    N, C, H, W = image_spatial.size()
    spatial_patches = image_to_patches(image_spatial)
    dct_patches = dct_8x8(spatial_patches)
    dct_coef = patches_to_image(dct_patches, H, W)
    for i, j in itertools.product(range(8), repeat=2):  # 先遍历j，后遍历i
        x_tmp = dct_coef[:, :, i::8, j::8]
        x = torch.cat((x, x_tmp), dim=1) if i+j else x_tmp
    y = x[:, 1:64, :, :]
    y = torch.abs(y)
    return y

# DCT系数反量化，按模式抽取
def jpeg_mode_cal_2(dct_coef, quality):
    N, C, H, W = dct_coef.size()
    Dct_patches = image_to_patches(dct_coef)
    dct_dequantize_patches = jpeg_dequantize(Dct_patches, quality)
    dct_coef_dequantize = patches_to_image(dct_dequantize_patches, H, W)
    for i, j in itertools.product(range(8), repeat=2):  # 先遍历j，后遍历i
        x_tmp = dct_coef_dequantize[:, :, i::8, j::8]
        x = torch.cat((x, x_tmp), dim=1) if i+j else x_tmp
    y = x[:, 1:64, :, :]
    # y = torch.abs(y)
    return y

# 空域图像，JPEG压缩后的DCT系数（有量化），按模式抽取
def jpeg_mode_cal_3(image_spatial, quality):  
    image_spatial = image_spatial - 128.0
    N, C, H, W = image_spatial.size()
    spatial_patches = image_to_patches(image_spatial)
    dct_patches = dct_8x8(spatial_patches)
    dct_patches = jpeg_quantize(dct_patches, quality)
    dct_coef = patches_to_image(dct_patches, H, W)
    for i, j in itertools.product(range(8), repeat=2):  # 先遍历j，后遍历i
        x_tmp = dct_coef[:, :, i::8, j::8]
        x = torch.cat((x, x_tmp), dim=1) if i+j else x_tmp
    y = x[:, 1:64, :, :]
    y = torch.abs(y)
    return y

def jpeg_mode_cal_4(image_spatial):
    image_spatial = image_spatial - 128.0
    N, C, H, W = image_spatial.size()
    spatial_patches = image_to_patches(image_spatial)
    dct_patches = dct_8x8(spatial_patches)
    dct_coef = patches_to_image(dct_patches, H, W)
    for i, j in itertools.product(range(8), repeat=2):  # 先遍历j，后遍历i
        x_tmp = dct_coef[:, :, i::8, j::8]
        x = torch.cat((x, x_tmp), dim=1) if i+j else x_tmp
    y = torch.abs(x)
    y[:, 0, :, :] = 0.5 * (y[:, 1, :, :] + y[:, 8, :, :])
    y = 1 / (y + 0.1)
    return y


# 将模式恢复为原始位置
def jpeg_mode2image(input):
    N, C, H, W = input.size()
    input = torch.cat([0.5 * (input[:, 1:2, :, :] + input[:, 8:9, :, :]), input[:, 1:, :, :]], dim=1)
    output = input.reshape([N, 8, 8, H, W])
    output = output.permute(0, 3, 1, 4, 2)
    output = output.reshape([N, 1, H*8, W*8])
    return output


# # JPEG_mode
# def JPEG_mode_2(mode_table, size, perc):
#     mode_table = 1. / (mode_table * perc)mode_table[0, 0]
#     mode_table = mode_table.repeat(int(size[2]/8), int(size[3]/8))
#     mode = mode_table.unsqueeze(0).unsqueeze(1)
#     mode = mode.expand(size)
#     return mode

# JPEG_mode
def JPEG_mode_3(mode_table, size, perc, device):
    # mode_table = quality_to_factor(95, device)
    # mode_table = torch.from_numpy(mode_table)
    mode_table = mode_table.cuda(device)
    mode_table[0, 0] = 0.5 * (mode_table[1, 0] + mode_table[0, 1])
    # mode_table = torch.from_numpy(mode_table)
    # mode_table = mode_table.cuda(device)
    mode_table = (mode_table * perc)
    mode_table = mode_table.repeat(int(size[2]/8), int(size[3]/8))
    mode = mode_table.unsqueeze(0).unsqueeze(1)
    mode = mode.expand(size)
    return mode

def JPEG_mode_4(mode_table, size, perc, device):
    # mode_table = mode_table.cuda(device)
    mode_table = quality_to_factor(95, device)
    mode_table[0, 0] = 0.5 * (mode_table[1, 0] + mode_table[0, 1])
    mode_table = (mode_table * perc)
    mode_table = mode_table.repeat(int(size[2]/8), int(size[3]/8))
    mode = mode_table.unsqueeze(0).unsqueeze(1)
    mode = mode.expand(size)
    return mode

def JPEG_mode_5(mode_table, size, perc):
    # mode_table = quality_to_factor(95, device)
    # mode_table = torch.from_numpy(mode_table)
    # mode_table = mode_table.cuda(device)
    # mode_table[0, 0] = 0.5 * (mode_table[1, 0] + mode_table[0, 1])
    # mode_table = torch.from_numpy(mode_table)
    # mode_table = mode_table.cuda(device)
    mode_table = (mode_table * perc)
    mode_table = mode_table.repeat(int(size[2]/8), int(size[3]/8))
    mode = mode_table.unsqueeze(0).unsqueeze(1)
    mode = mode.expand(size)
    return mode

def JPEG_table(QF, device):
    mode_table = quality_to_factor(QF, device)
    return mode_table

# 模式度量初始值
mode_table = np.array([
    [0.0071, 0.0071, 0.0079, 0.0202, 0.0255, 0.0552, 0.0681, 0.0761],
    [0.0071, 0.0084, 0.0092, 0.0228, 0.0418, 0.0886, 0.0860, 0.0797],
    [0.0079, 0.0092, 0.0200, 0.0245, 0.0588, 0.0926, 0.1042, 0.0825],
    [0.0101, 0.0228, 0.0245, 0.0434, 0.0831, 0.1522, 0.1274, 0.0875],
    [0.0255, 0.0279, 0.0588, 0.0997, 0.1266, 0.1942, 0.1607, 0.1163],
    [0.0276, 0.0590, 0.0926, 0.1014, 0.1412, 0.1665, 0.1617, 0.1183],
    [0.0681, 0.0860, 0.1191, 0.1433, 0.1607, 0.1764, 0.1514, 0.1116],
    [0.0888, 0.1195, 0.1375, 0.1459, 0.1599, 0.1315, 0.1116, 0.0982]
], dtype=np.float32)

# JPEG_mode
def JPEG_mode_ori():
    mode = torch.from_numpy(mode_table)
    return mode

# JPEG_mode
def Normalize_custom_0_1(input):
    pre_max = torch.max(input, 0, True)[0]
    pre_max = torch.max(pre_max, 1, True)[0]
    pre_min = torch.min(input, 0, True)[0]
    pre_min = torch.min(pre_min, 1, True)[0]
    input_norm = (input - pre_min) / (pre_max - pre_min + 0.000001) + 0.00000001
    return input_norm

# JPEG_mode
def Normalize_custom_0_1_2D(input):
    pre_max = torch.max(input, 2, True)[0]
    pre_max = torch.max(pre_max, 3, True)[0]
    pre_min = torch.min(input, 2, True)[0]
    pre_min = torch.min(pre_min, 3, True)[0]
    input_norm = (input - pre_min) / (pre_max - pre_min + 0.000001) + 0.00000001
    return input_norm

class Simulator(Function):
    @staticmethod
    def forward(ctx, noise, prob, lambda_p):
        # lambda_p = 1
        grad_tanh = torch.zeros_like(noise)
        grad_tanh[noise > (1-prob)] = lambda_p   # nosie > (1-prob), +1
        grad_tanh[noise < prob] = - lambda_p      # nosie < prob, -1
        ctx.save_for_backward(grad_tanh)
        output = torch.zeros_like(noise)
        output[noise > (1-prob)] = 1.0
        output[noise < prob] = -1.0
        return output
    @staticmethod
    def backward(ctx, grad_input):
        grad_tanh, = ctx.saved_variables
        gid = grad_input * grad_tanh
        return None, gid, None,

class Simulator_1(Function):
    @staticmethod
    def forward(ctx, noise, prob, lambda_p):
        # lambda_p = 1
        grad_1 = torch.tanh(lambda_p * (prob - noise))
        grad_1 = torch.pow(grad_1, 2)
        grad_2 = torch.tanh(lambda_p * (prob + noise - 1))
        grad_2 = torch.pow(grad_2, 2)
        grad_tanh = lambda_p * (grad_1 - grad_2) / 2
        ctx.save_for_backward(grad_tanh)
        output = torch.zeros_like(noise)
        output[noise > (1-prob)] = 1   # prob -> -1 modif.
        output[noise < prob] = -1
        return output
    @staticmethod
    def backward(ctx, grad_input):
        grad_tanh, = ctx.saved_variables
        gid = grad_input * grad_tanh
        return None, gid, None,

class Simulator_Asy(Function):
    @staticmethod
    def forward(ctx, noise, prob_p, prob_m, Lambda):
        # lambda_p = 1
        grad_tanh_p = - Lambda * (torch.pow(torch.tanh(Lambda * (prob_p - noise)), 2) - 1) / 2
        grad_tanh_m =   Lambda * (torch.pow(torch.tanh(Lambda * (prob_m  + noise - 1)), 2) - 1) / 2

        ctx.save_for_backward(grad_tanh_p, grad_tanh_m)
        output = torch.zeros_like(noise)
        output[noise > (1 - prob_m)] = -1.0
        output[noise < prob_p] = 1.0   # prob -> +1 modif.
        return output
    @staticmethod
    def backward(ctx, grad_input):
        grad_tanh_p, grad_tanh_m, = ctx.saved_variables
        gid_p = grad_input * grad_tanh_p
        gid_m = grad_input * grad_tanh_m
        return None, gid_p, gid_m, None,

class Simulator_Asy_1(Function):
    @staticmethod
    def forward(ctx, noise, prob_p, prob_m, Lambda):
        # lambda_p = 1
        grad_tanh_p = torch.zeros_like(noise)
        grad_tanh_p[noise < 0.5] = Lambda
        grad_tanh_m = torch.zeros_like(noise)
        grad_tanh_m[noise > 0.5] = - Lambda

        ctx.save_for_backward(grad_tanh_p, grad_tanh_m)
        output = torch.zeros_like(noise)
        output[noise > (1 - prob_m)] = -1.0
        output[noise < prob_p] = 1.0   # prob -> +1 modif.
        return output
    @staticmethod
    def backward(ctx, grad_input):
        grad_tanh_p, grad_tanh_m, = ctx.saved_variables
        gid_p = grad_input * grad_tanh_p
        gid_m = grad_input * grad_tanh_m
        return None, gid_p, gid_m, None,

class Simulator_4(Function):
    @staticmethod
    def forward(ctx, noise, prob, lambda_p):
        lambda_n = 1
        grad_1 = torch.tanh(lambda_n * (prob - noise))
        grad_1 = torch.pow(grad_1, 2)
        grad_2 = torch.tanh(lambda_n * (prob + noise - 1))
        grad_2 = torch.pow(grad_2, 2)
        grad_tanh = lambda_p * (grad_1 - grad_2) / 2

        ctx.save_for_backward(grad_tanh)
        output = torch.zeros_like(noise)
        output[noise > (1-prob)] = 1
        output[noise < prob] = -1
        return output

    @staticmethod
    def backward(ctx, grad_input):
        grad_tanh, = ctx.saved_variables
        gid = grad_input * grad_tanh
        return None, gid, None,

class Simulator_5(Function):
    @staticmethod
    def forward(ctx, noise, prob, lambda_p):
        # lambda_p = 1
        grad_tanh = torch.zeros_like(noise)
        grad_tanh[noise > 2/3] = lambda_p   # nosie > (1-prob), +1
        grad_tanh[noise < 1/3] = - lambda_p   # nosie < prob, -1
        ctx.save_for_backward(grad_tanh)
        output = torch.zeros_like(noise)
        output[noise > (1-prob)] = 1.0
        output[noise < prob] = -1.0
        return output
    @staticmethod
    def backward(ctx, grad_input):
        grad_tanh, = ctx.saved_variables
        gid = grad_input * grad_tanh
        return None, gid, None,

class SideinformEstAdjust(Function):
    # pm = torch.tanh(err * 100)
    # Embeding_cost_P = cost * (1 - self.factor * ((1 + err) / 2))  # round_err > 0  ->  +1 -> decrease cost_p
    # Embeding_cost_M = cost * (1 - self.factor * ((1 - err) / 2))  # round_err < 0  ->  -1 -> decrease cost_m
    @staticmethod
    def forward(ctx, cost, err, factor, Lambda):
        # lambda_p = 1
        # grad_tanh_cost_p = torch.ones_like(cost)
        # grad_tanh_cost_m = torch.ones_like(cost)
        # grad_tanh_cost_p[err > 0] = 1 - factor   # Embeding_cost_P 对 cost 的偏导
        # grad_tanh_cost_m[err < 0] = 1 - factor   # Embeding_cost_M 对 cost 的偏导

        grad_tanh_cost_p = 1 - 0.5 * factor * (1 + err)
        grad_tanh_cost_m = 1 - 0.5 * factor * (1 - err)
        grad_tanh_err_p = - 0.5 * factor * cost  # cost * Lambda * factor   # Embeding_cost_P 对 err 的偏导
        grad_tanh_err_m = 0.5 * factor * cost    # cost * Lambda * factor     # Embeding_cost_P 对 err 的偏导

        # grad_tanh_err_p = - Lambda * torch.ones_like(cost)
        # grad_tanh_err_m = Lambda * torch.ones_like(cost)


        ctx.save_for_backward(grad_tanh_cost_p, grad_tanh_cost_m, grad_tanh_err_p, grad_tanh_err_m)

        cost_tmp = cost* (1.0 - factor)
        Embeding_cost_P =torch.where(err > 0., cost_tmp, cost)
        Embeding_cost_M =torch.where(err < 0., cost_tmp, cost)

        return Embeding_cost_P, Embeding_cost_M
    @staticmethod
    def backward(ctx, grad_input1, grad_input2):
        grad_tanh_cost_p, grad_tanh_cost_m, grad_tanh_err_p, grad_tanh_err_m = ctx.saved_variables
        gid_cost = grad_input1 * grad_tanh_cost_p + grad_input2 * grad_tanh_cost_m
        gid_err = grad_input1 * grad_tanh_err_p + grad_input2 * grad_tanh_err_m
        return gid_cost, gid_err, None, None,


def prob_cal(Embeding_cost):
    Embeding_pho = - Embeding_cost + 0.6931
    Embeding_prob = torch.sigmoid(Embeding_pho)
    return Embeding_prob


class SideinformEstAdjust_2(Function):
    # pm = torch.tanh(err * 100)
    # Embeding_cost_P = cost * (1 - self.factor * ((1 + err) / 2))  # round_err > 0  ->  +1 -> decrease cost_p
    # Embeding_cost_M = cost * (1 - self.factor * ((1 - err) / 2))  # round_err < 0  ->  -1 -> decrease cost_m
    @staticmethod
    def forward(ctx, cost, err, factor, Lambda):
        # lambda_p = 1
        grad_tanh_cost_p = torch.ones_like(cost)
        grad_tanh_cost_m = torch.ones_like(cost)
        grad_tanh_cost_p[err > 0] = 1 - factor   # Embeding_cost_P 对 cost 的偏导
        grad_tanh_cost_m[err < 0] = 1 - factor   # Embeding_cost_M 对 cost 的偏导

        grad_tanh_err_p = - 0.5 * factor * cost  # cost * Lambda * factor   # Embeding_cost_P 对 err 的偏导
        grad_tanh_err_m = 0.5 * factor * cost    # cost * Lambda * factor     # Embeding_cost_P 对 err 的偏导

        # grad_tanh_err_p = - Lambda * torch.ones_like(cost)
        # grad_tanh_err_m = Lambda * torch.ones_like(cost)


        ctx.save_for_backward(grad_tanh_cost_p, grad_tanh_cost_m, grad_tanh_err_p, grad_tanh_err_m)

        cost_tmp = cost* (1.0 - factor)
        Embeding_cost_P =torch.where(err > 0., cost_tmp, cost)
        Embeding_cost_M =torch.where(err < 0., cost_tmp, cost)

        return Embeding_cost_P, Embeding_cost_M
    @staticmethod
    def backward(ctx, grad_input1, grad_input2):
        grad_tanh_cost_p, grad_tanh_cost_m, grad_tanh_err_p, grad_tanh_err_m = ctx.saved_variables
        gid_cost = grad_input1 * grad_tanh_cost_p + grad_input2 * grad_tanh_cost_m
        gid_err = grad_input1 * grad_tanh_err_p + grad_input2 * grad_tanh_err_m
        return gid_cost, gid_err, None, None,

def prob_cal_2(Embeding_cost, round_err, factor):
    # pm = torch.tanh(round_err * 100)
    # Embeding_cost_P = Embeding_cost * (1 - factor * ((1 + pm) / 2))  # round_err > 0  ->  +1 -> decrease cost_p
    # Embeding_cost_M = Embeding_cost * (1 - factor * (1 - pm) / 2)  # round_err < 0  ->  -1 -> decrease cost_m
    Lambda = 30.0
    Embeding_cost_P, Embeding_cost_M = SideinformEstAdjust_2.apply(Embeding_cost, round_err, factor, Lambda)

    # cost_P = Embeding_cost_P[0]
    # cost_P = torch.squeeze(cost_P, dim=0)  # 删除第1维度
    # io.savemat('cost_P.mat', {'cost_P': cost_P.detach().cpu().numpy().astype('float16')})

    # cost_M = Embeding_cost_M[0]
    # cost_M = torch.squeeze(cost_M, dim=0)  # 删除第1维度
    # io.savemat('cost_M.mat', {'cost_M': cost_M.detach().cpu().numpy().astype('float16')})


    # Embeding_cost_P = Embeding_cost * (1 - factor * (1 + torch.sign(round_err)) / 2)
    # Embeding_cost_M = Embeding_cost * (1 - factor * (1 - torch.sign(round_err)) / 2)

    temp = 1 + torch.exp(- Embeding_cost_P) + torch.exp(- Embeding_cost_M)
    Embeding_prob_P = torch.exp(- Embeding_cost_P) / temp
    Embeding_prob_M = torch.exp(- Embeding_cost_M) / temp
    Embeding_prob = [Embeding_prob_P, Embeding_prob_M]
    return Embeding_prob

class SideinformEstAdjust_3(Function):
    # pm = torch.tanh(err * 100)
    # Embeding_cost_P = cost * (1 - self.factor * ((1 + err) / 2))  # round_err > 0  ->  +1 -> decrease cost_p
    # Embeding_cost_M = cost * (1 - self.factor * ((1 - err) / 2))  # round_err < 0  ->  -1 -> decrease cost_m
    @staticmethod
    def forward(ctx, cost, err, factor):
        # lambda_p = 1
        # grad_tanh_cost_p = torch.ones_like(cost)
        # grad_tanh_cost_m = torch.ones_like(cost)
        # grad_tanh_cost_p[err > 0] = 1 - factor   # Embeding_cost_P 对 cost 的偏导
        # grad_tanh_cost_m[err < 0] = 1 - factor   # Embeding_cost_M 对 cost 的偏导
        
        grad_tanh_cost_p = 1 - 0.5 * factor * (1 + err)
        grad_tanh_cost_m = 1 - 0.5 * factor * (1 - err)
        grad_tanh_err_p = - 0.5 * factor * cost
        grad_tanh_err_m = 0.5 * factor * cost

        ctx.save_for_backward(grad_tanh_cost_p, grad_tanh_cost_m, grad_tanh_err_p, grad_tanh_err_m)

        cost_tmp = cost* (1.0 - factor)
        Embeding_cost_P =torch.where(err > 0., cost_tmp, cost)
        Embeding_cost_M =torch.where(err < 0., cost_tmp, cost)

        return Embeding_cost_P, Embeding_cost_M
    @staticmethod
    def backward(ctx, grad_input1, grad_input2):
        grad_tanh_cost_p, grad_tanh_cost_m, grad_tanh_err_p, grad_tanh_err_m = ctx.saved_variables
        gid_cost = grad_input1 * grad_tanh_cost_p + grad_input2 * grad_tanh_cost_m
        gid_err = grad_input1 * grad_tanh_err_p + grad_input2 * grad_tanh_err_m
        return gid_cost, gid_err, None, None,

def prob_cal_3(Embeding_cost, round_err, factor):
    Embeding_cost_P, Embeding_cost_M = SideinformEstAdjust_3.apply(Embeding_cost, round_err, factor)
    temp = 1 + torch.exp(- Embeding_cost_P) + torch.exp(- Embeding_cost_M)
    Embeding_prob_P = torch.exp(- Embeding_cost_P) / temp
    Embeding_prob_M = torch.exp(- Embeding_cost_M) / temp
    Embeding_prob = [Embeding_prob_P, Embeding_prob_M]
    return Embeding_prob