# -*- coding: utf-8 -*-

import zlib
import math
from math import exp
import numpy as np
import torch
# from reedsolo import RSCodec
from torch.nn.functional import conv2d
import itertools
import scipy.io as io
from torch import nn
from torch.autograd import Function
import torch.nn.functional as F


# t_table = np.array(
#     [[16, 11, 10, 16, 24, 40, 51, 61], [12, 12, 14, 19, 26, 58, 60, 55],
# 	 [14, 13, 16, 24, 40, 57, 69, 56], [14, 17, 22, 29, 51, 87, 80, 62],
# 	 [18, 22, 37, 56, 68, 109, 103, 77], [24, 35, 55, 64, 81, 104, 113, 92],
#      [49, 64, 78, 87, 103, 121, 120, 101], [72, 92, 95, 98, 112, 100, 103, 99]],dtype=np.float32)

alpha = np.array([1. / np.sqrt(2)] + [1] * 7, dtype=np.float32)
alpha = np.outer(alpha, alpha)

cos_tensor_idct = np.zeros((8, 8, 8, 8), dtype=np.float32)
for u, v, i, j in itertools.product(range(8), repeat=4):
    cos_tensor_idct[u, v, i, j] = np.cos((2 * i + 1) * u * np.pi / 16) * np.cos(
        (2 * j + 1) * v * np.pi / 16)

cos_tensor_dct = np.zeros((8, 8, 8, 8), dtype=np.float32)
for i, j, u, v in itertools.product(range(8), repeat=4):
    cos_tensor_dct[i, j, u, v] = np.cos((2 * i + 1) * u * np.pi / 16) * np.cos((2 * j + 1) * v * np.pi / 16)

def text_to_bits(text):
    """Convert text to a list of ints in {0, 1}"""
    return bytearray_to_bits(text_to_bytearray(text))


def bits_to_text(bits):
    """Convert a list of ints in {0, 1} to text"""
    return bytearray_to_text(bits_to_bytearray(bits))


def bytearray_to_bits(x):
    """Convert bytearray to a list of bits"""
    result = []
    for i in x:
        bits = bin(i)[2:]
        bits = '00000000'[len(bits):] + bits
        result.extend([int(b) for b in bits])

    return result


def bits_to_bytearray(bits):
    """Convert a list of bits to a bytearray"""
    ints = []
    for b in range(len(bits) // 8):
        byte = bits[b * 8:(b + 1) * 8]
        ints.append(int(''.join([str(bit) for bit in byte]), 2))

    return bytearray(ints)


def text_to_bytearray(text):
    """Compress and add error correction"""
    assert isinstance(text, str), "expected a string"
    x = zlib.compress(text.encode("utf-8"))
    x = rs.encode(bytearray(x))

    return x


def bytearray_to_text(x):
    """Apply error correction and decompress"""
    try:
        text = rs.decode(x)
        text = zlib.decompress(text)
        return text.decode("utf-8")
    except BaseException:
        return False


def first_element(storage, loc):
    """Returns the first element of two"""
    return storage


def gaussian(window_size, sigma):
    """Gaussian window.

    https://en.wikipedia.org/wiki/Window_function#Gaussian_window
    """
    _exp = [exp(-(x - window_size // 2) ** 2 / float(2 * sigma ** 2)) for x in range(window_size)]
    gauss = torch.Tensor(_exp)
    return gauss / gauss.sum()


def create_window(window_size, channel):
    _1D_window = gaussian(window_size, 1.5).unsqueeze(1)
    _2D_window = _1D_window.mm(_1D_window.t()).float().unsqueeze(0).unsqueeze(0)
    window = _2D_window.expand(channel, 1, window_size, window_size).contiguous()
    return window


def _ssim(img1, img2, window, window_size, channel, size_average=True):

    padding_size = window_size // 2

    mu1 = conv2d(img1, window, padding=padding_size, groups=channel)
    mu2 = conv2d(img2, window, padding=padding_size, groups=channel)

    mu1_sq = mu1.pow(2)
    mu2_sq = mu2.pow(2)
    mu1_mu2 = mu1 * mu2

    sigma1_sq = conv2d(img1 * img1, window, padding=padding_size, groups=channel) - mu1_sq
    sigma2_sq = conv2d(img2 * img2, window, padding=padding_size, groups=channel) - mu2_sq
    sigma12 = conv2d(img1 * img2, window, padding=padding_size, groups=channel) - mu1_mu2

    C1 = 0.01**2
    C2 = 0.03**2

    _ssim_quotient = ((2 * mu1_mu2 + C1) * (2 * sigma12 + C2))
    _ssim_divident = ((mu1_sq + mu2_sq + C1) * (sigma1_sq + sigma2_sq + C2))

    ssim_map = _ssim_quotient / _ssim_divident

    if size_average:
        return ssim_map.mean()
    else:
        return ssim_map.mean(1).mean(1).mean(1)


def ssim(img1, img2, window_size=11, size_average=True):
    (_, channel, _, _) = img1.size()
    window = create_window(window_size, channel)

    if img1.is_cuda:
        window = window.cuda(img1.get_device())
    window = window.type_as(img1)

    return _ssim(img1, img2, window, window_size, channel, size_average)


y_table = np.array(
    [[16, 11, 10, 16, 24, 40, 51, 61], [12, 12, 14, 19, 26, 58, 60, 55],
     [14, 13, 16, 24, 40, 57, 69, 56], [14, 17, 22, 29, 51, 87, 80, 62],
     [18, 22, 37, 56, 68, 109, 103, 77], [24, 35, 55, 64, 81, 104, 113, 92],
     [49, 64, 78, 87, 103, 121, 120, 101], [72, 92, 95, 98, 112, 100, 103, 99]], dtype=np.float32)

c_table = np.empty((8, 8), dtype=np.float32)
c_table.fill(99)
c_table[:4, :4] = np.array([[17, 18, 24, 47],
                            [18, 21, 26, 66],
                            [24, 26, 56, 99],
                            [47, 66, 99, 99]])

def quality_to_factor(quality, device, T_table):
    t_table = torch.from_numpy(T_table)
    if (quality <= 0):
        quality = 1
    if (quality > 100):
        quality = 100
    if quality < 50:
        quality = 5000. / quality
    else:
        quality = 200. - quality * 2
    
    
    table = (t_table.cuda(device) * quality + 50.) / 100.
    # table = (t_table.cuda(device) * quality) / 100.

    table = torch.floor(table)
    x = torch.ones(table.size()).cuda(table.get_device())
    torch.where(table < 1, x, table)
    return table

def jpeg_quantize(patches, quality, T_table):
    # quality = torch.from_numpy(quality)
    table = quality_to_factor(quality, patches.get_device(), T_table)
    # y_table = torch.from_numpy(y_table)
    table = table.floor()
    table = table.unsqueeze(0).unsqueeze(1)
    table = table.expand(patches.size())
    return patches / table

# y_table = quality_to_factor(quality)
def jpeg_dequantize(patches, quality, T_table):
    # quality = torch.from_numpy(quality)
    y_table = quality_to_factor(quality, patches.get_device(), T_table)
    # y_table = torch.from_numpy(y_table)
    y_table = y_table.floor()
    y_table = y_table.unsqueeze(0).unsqueeze(1)
    y_table = y_table.expand(patches.size())
    return patches * y_table


def image_to_patches(input):
    # input: batch x 1 x h x w
    # output: batch x h*w/64 x h x w
    k = 8
    input = torch.squeeze(input, dim=1)  # 删除第1维度
    batch_size, H, W = input.size()
    input_reshaped = input.view(batch_size, H // k, k, W // k, k)
    patches = input_reshaped.permute(0, 1, 3, 2, 4)
    return patches.reshape(batch_size, -1, k, k)


def patches_to_image(patches, height, width):
    # input: batch x h*w/64 x h x w
    # output: batch x h x w
    k = 8
    batch_size = patches.size(0)
    image_reshaped = patches.view(batch_size, height // k, width // k, k, k)
    image_reshaped = image_reshaped.permute(0, 1, 3, 2, 4)
    output = image_reshaped.reshape(batch_size, 1, height, width)
    return output

def dct_8x8(input):
    Alpha = torch.from_numpy(alpha)
    image = input
    tensor = torch.from_numpy(cos_tensor_dct)
    result = torch.einsum("ijkl,klmn->ijmn", (image, tensor.cuda(input.get_device())))
    result = 0.25 * result * Alpha.cuda(input.get_device())
    return result

def idct_8x8(input):
    Alpha = torch.from_numpy(alpha)
    image = 0.25 * input * Alpha.cuda(input.get_device())
    tensor = torch.from_numpy(cos_tensor_idct)
    result = torch.einsum("ijkl,klmn->ijmn", (image, tensor.cuda(input.get_device())))
    return result + 128.0

def jpeg_decompress(dct, quality, T_table):
    N, C, H, W = dct.size()
    Dct_patches = image_to_patches(dct)
    dct_dequantize_patches = jpeg_dequantize(Dct_patches, quality, T_table)
    decomp_patches = idct_8x8(dct_dequantize_patches)
    decomp = patches_to_image(decomp_patches, H, W)
    # cover_dct1 = decomp[0]
    # cover_dct1 = torch.squeeze(cover_dct1, dim=0)  # 删除第1维度
    # io.savemat('de_cover.mat', {'de_cover': cover_dct1.detach().cpu().numpy().astype('float16')})
    return decomp

def jpeg_compress(image_spatial, quality, T_table):
    image_spatial = image_spatial - 128.0
    N, C, H, W = image_spatial.size()
    spatial_patches = image_to_patches(image_spatial)
    dct_patches = dct_8x8(spatial_patches)
    dct_patches = jpeg_quantize(dct_patches, quality, T_table)
    dct_coef = patches_to_image(dct_patches, H, W)
    dct_coef = torch.round(dct_coef)
    # print(dct_coef)

    return dct_coef



def rgb2yuv(image_rgb, image_yuv_out):
    """ Transform the image from rgb to yuv """
    image_yuv_out[:, 0, :, :] = 0.299 * image_rgb[:, 0, :, :].clone() + 0.587 * image_rgb[:, 1, :, :].clone() + 0.114 * image_rgb[:, 2, :, :].clone()
    image_yuv_out[:, 1, :, :] = -0.168736 * image_rgb[:, 0, :, :].clone() + -0.331264 * image_rgb[:, 1, :, :].clone() + 0.5 * image_rgb[:, 2, :, :].clone() + 128.
    image_yuv_out[:, 2, :, :] = 0.5 * image_rgb[:, 0, :, :].clone() + -0.418688 * image_rgb[:, 1, :, :].clone() + -0.081312 * image_rgb[:, 2, :, :].clone() + 128.


def yuv2rgb(image_yuv, image_rgb_out):
    """ Transform the image from yuv to rgb """
    image_rgb_out[:, 0, :, :] = image_yuv[:, 0, :, :].clone() + 1.1402 * (image_yuv[:, 2, :, :].clone()-128.)
    image_rgb_out[:, 1, :, :] = image_yuv[:, 0, :, :].clone() + -0.344136 * (image_yuv[:, 1, :, :].clone()-128.) + -0.714136 * (image_yuv[:, 2, :, :].clone()-128.)
    image_rgb_out[:, 2, :, :] = image_yuv[:, 0, :, :].clone() + 1.772 * (image_yuv[:, 1, :, :].clone()-128.)



def downsampling_420(image):
    y, cb, cr = torch.split(image, 1, dim=1)
    cb = F.avg_pool2d(cb, 2)
    cr = F.avg_pool2d(cr, 2)
    return (y, cb, cr)

def upsampling_420(y, cb, cr):
    def repeat(x, n=2):
        h, w = x.shape[2:4]
        x = x.unsqueeze(-1).repeat(1, 1, 1, n, n).view(-1, 1, h*n, w*n)
        return x

    cb = repeat(cb)
    cr = repeat(cr)
    return torch.cat((y, cb, cr), dim=1)





class SUJPEG(nn.Module):
    def __init__(self, height=128, width=128, quality=75):
        ''' Initialize the DiffJPEG layer
        Inputs:
            height(int): Original image height
            width(int): Original image width
            differentiable(bool): If true uses custom differentiable
                rounding function, if false uses standrard torch.round
            quality(float): Quality factor for jpeg compression scheme. 
        '''
        super(SUJPEG, self).__init__()
        
        self.quality = quality

        # self.compress = compress_jpeg(rounding=rounding, factor=factor)
        # self.decompress = decompress_jpeg(height, width, rounding=rounding,
        #                                   factor=factor)

    def forward(self, x):
        '''
        '''
        x = torch.clamp(x,-1,1)
        image_rgb = torch.round(255.0 * (x + 1.0) / 2.0)

        image_yuv = torch.empty_like(image_rgb)
        rgb2yuv(image_rgb, image_yuv)
        y, cb, cr = downsampling_420(image_yuv)

        dct_y = jpeg_compress(y,self.quality, y_table)
        dct_cb = jpeg_compress(cb,self.quality, c_table)
        dct_cr = jpeg_compress(cr,self.quality, c_table)

        y_out = jpeg_decompress(dct_y, self.quality, y_table)
        cb_out = jpeg_decompress(dct_cb, self.quality, c_table)
        cr_out = jpeg_decompress(dct_cr, self.quality, c_table)


        image_yuv_out = upsampling_420(y_out, cb_out, cr_out)
        

        # transform from yuv to to rgb
        image_rgb_out = torch.empty_like(image_yuv_out)
        yuv2rgb(image_yuv_out, image_rgb_out)
        

        #截断到0到255

        image_rgb_out = torch.clamp(image_rgb_out,0,255)

        # print(torch.max())

                    
                    
        # x_clone = x.clone()
        # x_detach = x_clone.detach()

        out = image_rgb_out / 127.5 - 1.0

        # gap = recovered - x_detach

        # out = x+gap
        # print("sum of residual")
        # print(torch.sum(gap))


        return out





###############################################################################################################################################################
###############################################################################################################################################################
###############################################################################################################################################################
###############################################################################################################################################################
###############################################################################################################################################################
###############################################################################################################################################################
##################################################################################################################################################################






