import torch


def round01(x):
    
    x = torch.clamp(x,0,1)
    x = torch.round(255.0 * x )
    x = x/255.0
    return x





def round_1to1(x):
    x = torch.clamp(x,-1,1)
    x = torch.round(255.0 * (x + 1.0) / 2.0)
    x = x / 127.5 - 1.0

    return x
