from torch import round
import torch.nn as nn
from torch.nn import functional as F
from noise_layers.t_utils import *



class AF(nn.Module):
	def __init__(self, kernel=5):
		super(AF, self).__init__()
		self.kernel = kernel
		
	def forward(self, image):
		image = round(255.0 * (image + 1.0) / 2.0)
		image /= 255.0
		# [-1,1] - > [0,1]

		image = F.avg_pool2d(image, kernel_size=self.kernel, stride=1, padding=int(self.kernel/2), count_include_pad=False)

		image = round01(image)
		
		#[0,1] -> [-1,1]

		image *= 255.0
		image = image / 127.5 - 1.0
		
    
        
		
		return image


