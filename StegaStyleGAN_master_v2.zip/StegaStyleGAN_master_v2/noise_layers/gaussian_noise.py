import numpy as np
import torch
import torch.nn as nn
from noise_layers.t_utils import *

# class GN(nn.Module):

# 	def __init__(self, mean=0, var=0.1):
# 		super(GN, self).__init__()
# 		self.var = var
# 		self.mean = mean

# 	def gaussian_noise(self, image, mean, var):
# 		noise = torch.Tensor(np.random.normal(mean, var ** 0.5, image.shape)).to(image.device)
# 		out = image + noise
# 		return out

# 	def forward(self, image):
		

# 		image = torch.round(255.0 * (image + 1.0) / 2.0)
# 		image /= 255.0
# 		# [-1,1] - > [0,1]
# 		image = self.gaussian_noise(image, self.mean, self.var)
# 		#[0,1] -> [-1,1]
# 		image *= 255.0
# 		image = image / 127.5 - 1.0


# 		# image = self.gaussian_noise(image, self.mean, self.var)


# 		return image



class GN(nn.Module):
	def __init__(self, mean=0, var=0.1):
		super(GN, self).__init__()
		self.var = var
		self.mean = mean

	def gauss_noise(self, image):
		noise = torch.normal(self.mean, self.var,size=image.shape).cuda()
		
		mixed =  image + noise
		# mixed = torch.clamp(mixed, 0, 1)

		return mixed


	def forward(self, image):
		

		# image = self.gauss_noise(image)

		# image = torch.round(255.0 * (image + 1.0) / 2.0)
		# image /= 255.0
		# [-1,1] - > [0,1]
		image = self.gauss_noise(image)
		image = round_1to1(image)
		#[0,1] -> [-1,1]
		# image *= 255.0
		# image = image / 127.5 - 1.0
		

		return image

