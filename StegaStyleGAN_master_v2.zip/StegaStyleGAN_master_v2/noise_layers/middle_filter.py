import torch.nn as nn
from kornia.filters import MedianBlur
import torch
from noise_layers.t_utils import *

class MF(nn.Module):

	def __init__(self, kernel):
		super(MF, self).__init__()
		self.middle_filter = MedianBlur((kernel, kernel))

	def forward(self, image):
		# image

		image = torch.round(255.0 * (image + 1.0) / 2.0)
		image /= 255.0
		# [-1,1] - > [0,1]
		image = self.middle_filter(image)
		image = round01(image)
		#[0,1] -> [-1,1]
		image *= 255.0
		image = image / 127.5 - 1.0

		return image

