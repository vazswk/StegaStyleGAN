import torch
import torch.nn as nn
from noise_layers.t_utils import *


class SP(nn.Module):

	def __init__(self, prob):
		super(SP, self).__init__()
		self.prob = prob

	def sp_noise(self, image, prob):
		prob_zero = prob / 2
		prob_one = 1 - prob_zero
		rdn = torch.rand(image.shape).to(image.device)

		output = torch.where(rdn > prob_one, torch.zeros_like(image).to(image.device), image)
		output = torch.where(rdn < prob_zero, torch.ones_like(output).to(output.device), output)

		return output

	def forward(self, image):
		
		image = torch.round(255.0 * (image + 1.0) / 2.0)
		image /= 255.0
		# [-1,1] - > [0,1]
		image = self.sp_noise(image, self.prob)
		image = round01(image)
		#[0,1] -> [-1,1]
		image *= 255.0
		image = image / 127.5 - 1.0


		return image
	
		# return self.sp_noise(image, self.prob)
