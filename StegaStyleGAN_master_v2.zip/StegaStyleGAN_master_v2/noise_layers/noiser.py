import numpy as np
import torch.nn as nn
from noise_layers.identity import Identity
from noise_layers.jpeg_compression3 import JpegCompression
from noise_layers.quantization import Quantization
from noise_layers.resize import Resize
from noise_layers.asl_jpeg import ASLJPEG
from noise_layers.real_jpeg import REALJPEG
from noise_layers.su_jpeg import SUJPEG
from noise_layers.gaussian_filter import GF
from noise_layers.gaussian_noise import GN
from noise_layers.middle_filter import MF
from noise_layers.salt_pepper_noise import SP
from noise_layers.avgfilter import AF
from noise_layers.rotate import Rotate
from noise_layers.speckle_noise import Speckle

class Noiser(nn.Module):
    """
    This module allows to combine different noise layers into a sequential noise module. The
    configuration and the sequence of the noise layers is controlled by the noise_config parameter.
    """
    def __init__(self, noise_layers: list, device, mode=1, prob=None):
        super(Noiser, self).__init__()
        self.noise_layers = []
        for layer in noise_layers:
            if type(layer) is str:
                if layer == 'JpegPlaceholder':
                    self.noise_layers.append(JpegCompression(device, quality=75))
                elif layer == 'ASLJpeg':
                    self.noise_layers.append(ASLJPEG(height=32, width=32, quality=75))
                elif layer == 'REALJpeg':
                    self.noise_layers.append(REALJPEG(height=32, width=32, quality=75))
                elif layer == 'SUJpeg':
                    self.noise_layers.append(SUJPEG(quality=75))
                elif layer == 'Resize':
                    self.noise_layers.append(Resize(resize_ratio_range=(0.5, 2.), interpolation_method='nearest'))
                else:
                    raise ValueError(f'Wrong layer placeholder string in Noiser.__init__().'
                                     f' Expected "JpegPlaceholder" or "QuantizationPlaceholder" but got {layer} instead')
            else:
                self.noise_layers.append(layer)
        # self.noise_layers = nn.Sequential(*noise_layers)
        self.mode = mode
        self.p = prob

    def forward(self, x, *args, **kwargs):
        if self.mode==0: # dont include Identity
            choice_layers = []
            layers_num = np.random.randint(0, len(self.noise_layers)+1)
            for i in range(layers_num):
                choice_layers.append(self.noise_layers.pop(np.random.randint(0, len(self.noise_layers))))
            for layer in choice_layers:
                if x.shape[2]!=128 or x.shape[3]!=128:
                    x = nn.functional.interpolate(x, size=(128, 128), mode='nearest')
                x = layer(x)
            self.noise_layers = choice_layers + self.noise_layers
        else:
            random_noise_layer = np.random.choice(self.noise_layers, 1, p=self.p)[0]
            x = random_noise_layer(x,  *args, **kwargs)

        return x

