import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import torch
from torchvision import transforms
import random
from noise_layers.t_utils import *

class Rotate(nn.Module):
    """
    Resize the image. The target size is original size * resize_ratio
    """
    def __init__(self, degree=50, size=128, interpolation_method='bilinear'):
        super(Rotate, self).__init__()
    
        self.interpolation_method = interpolation_method
        # self.rotate = transforms.RandomRotation(degrees=degree,expand=True)

        # self.transform = transforms.Compose(
        #     [
        #         transforms.RandomRotation(degrees=degree,expand=True,interpolation=transforms.InterpolationMode.BILINEAR),
        #         transforms.Resize(size, interpolation=transforms.InterpolationMode.BILINEAR)
        #     ]
        # )


        self.transform1 = transforms.Compose(
            [
                transforms.RandomRotation(degrees=(degree,degree),expand=True,interpolation=transforms.InterpolationMode.BILINEAR),
                
                # transforms.Resize(size, interpolation=transforms.InterpolationMode.BILINEAR),
            ]
        )

        self.transform2 = transforms.Compose(
            [
                transforms.RandomRotation(degrees=(-degree,-degree),expand=False,interpolation=transforms.InterpolationMode.BILINEAR),
                transforms.CenterCrop(size)
                
                # transforms.Resize(size, interpolation=transforms.InterpolationMode.BILINEAR),
            ]
        )
        


        # self.transform10 = transforms.Compose(
        #     [
        #         transforms.RandomRotation(degrees=(10,10),expand=True,interpolation=transforms.InterpolationMode.BILINEAR),
        #         transforms.Resize(size, interpolation=transforms.InterpolationMode.BILINEAR)
        #     ]
        # )

        # self.transform30 = transforms.Compose(
        #     [
        #         transforms.RandomRotation(degrees=(30,30),expand=True,interpolation=transforms.InterpolationMode.BILINEAR),
        #         transforms.Resize(size, interpolation=transforms.InterpolationMode.BILINEAR)
        #     ]
        # )

        # self.transform50 = transforms.Compose(
        #     [
        #         transforms.RandomRotation(degrees=(50,50),expand=True,interpolation=transforms.InterpolationMode.BILINEAR),
        #         transforms.Resize(size, interpolation=transforms.InterpolationMode.BILINEAR)
        #     ]
        # )


    def forward(self, image):
        image = torch.round(255.0 * (image + 1.0) / 2.0)
        image /= 255.0

        # t = random.choice([0,1,2])
        # if t==0:
        #     # print("0")
        #     image = self.transform10(image)
        # elif t==1:
        #     # print("1")
        #     image = self.transform10(image)
        # elif t==2:
        #     # print("2")
        #     image = self.transform10(image)

        image = self.transform1(image)

        image = round01(image)

        image = self.transform2(image)


        
        
        image *= 255.0
        image = image / 127.5 - 1.0


        # image = torch.round(255.0 * (image + 1.0) / 2.0)
        # image = image / 127.5 - 1.0

        return image
