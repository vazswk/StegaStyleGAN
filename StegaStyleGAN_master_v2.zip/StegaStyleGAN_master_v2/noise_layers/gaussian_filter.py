from torch import round
import torch.nn as nn
from kornia.filters import GaussianBlur2d
from noise_layers.t_utils import *


class GF(nn.Module):

	def __init__(self, sigma=1, kernel=7):
		super(GF, self).__init__()
		self.gaussian_filter = GaussianBlur2d((kernel, kernel), (sigma, sigma))

	def forward(self, image):
		# image
		image = round(255.0 * (image + 1.0) / 2.0)
		image /= 255.0
		# [-1,1] - > [0,1]
		image = self.gaussian_filter(image) 
		image = round01(image)
		#[0,1] -> [-1,1]
		image *= 255.0
		image = image / 127.5 - 1.0
		
        

		return image

