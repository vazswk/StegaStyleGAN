import torch
import torch.nn as nn
from noise_layers.t_utils import *



class Speckle(nn.Module):

    def __init__(self, std = 0.05):
        super(Speckle, self).__init__()
        self.std = std
        
    def speckle_noise(self, image):
        noise = torch.normal(0, self.std,size=image.shape).cuda()
        image = image + image * noise
        return image

    def forward(self, image):
        
        image = torch.round(255.0 * (image + 1.0) / 2.0)
        image /= 255.0
        # [-1,1] - > [0,1]


        image = self.speckle_noise(image)
        image = round01(image)
        


        #[0,1] -> [-1,1]
        image *= 255.0
        image = image / 127.5 - 1.0


        return image
    
        # return self.sp_noise(image, self.prob)
